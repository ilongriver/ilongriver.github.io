class Script extends VD.Component {
  /**
   * 组件挂载时调用：初始化资源、订阅事件、设置初始状态（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例。常用字段：core.timer（计时器）、core.render.scene（三维场景）、core.render.camera（当前相机）、core.container（DOM 容器）
   */
  onMount(core) {
    const dpr = window.devicePixelRatio

    core.render.scene.overrideMaterial = new THREE.MeshBasicNodeMaterial();

    //

    const geometry = new THREE.TorusKnotGeometry(1, 0.3, 128, 64);

    const count = 50;
    const scale = 5;

    for (let i = 0; i < count; i++) {

      const r = Math.random() * 2.0 * Math.PI;
      const z = (Math.random() * 2.0) - 1.0;
      const zScale = Math.sqrt(1.0 - z * z) * scale;

      const mesh = new THREE.Mesh(geometry);
      mesh.position.set(
        Math.cos(r) * zScale,
        Math.sin(r) * zScale,
        z * scale
      );
      mesh.rotation.set(Math.random(), Math.random(), Math.random());
      core.render.scene.add(mesh);

    }

    const depthTexture = new THREE.DepthTexture();
    depthTexture.type = THREE.FloatType;

    this.renderTarget = new THREE.RenderTarget(window.innerWidth * dpr, window.innerHeight * dpr);
    this.renderTarget.depthTexture = depthTexture;

    // FX

    const materialFX = new THREE.MeshBasicNodeMaterial();
    materialFX.colorNode = TSL.texture(depthTexture);

    this.quad = new THREE.QuadMesh(materialFX);

    core.render.render = () => {}
  }

  onResize() {
    const dpr = window.devicePixelRatio

    this.renderTarget.setSize(window.innerWidth * dpr, window.innerHeight * dpr);
  }

  /**
   * 组件卸载时调用：释放资源、取消订阅、清理监听器（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例，字段含义同 onMount
   */
  onUnmount(core) {

  }

  /**
   * 每帧更新回调：处理实时逻辑（运动、动画、碰撞检测、AI 等），会持续触发
   * @param {VD.Core} core 引擎核心实例。core.timer.getDelta() 可获取上一帧到当前的间隔秒数，常用于基于时间增量的位移 / 旋转
   */
  onUpdate(core) {
    core.render.renderer.setRenderTarget(this.renderTarget);
    core.render.renderer.render(core.render.scene, core.render.camera);

    core.render.renderer.setRenderTarget(null);
    this.quad.render(core.render.renderer);
  }
}