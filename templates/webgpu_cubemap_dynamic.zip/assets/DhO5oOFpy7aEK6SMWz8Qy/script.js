class Script extends VD.Component {
  /**
   * @field
   * @type {THREE.Texture}
   */
  texture
  /**
   * @field
   * @type {THREE.Texture}
   */
  uvTexture
  /**
   * 组件挂载时调用：初始化资源、订阅事件、设置初始状态（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例。常用字段：core.timer（计时器）、core.render.scene（三维场景）、core.render.camera（当前相机）、core.container（DOM 容器）
   */
  onMount(core) {
    this.cubeRenderTarget = new THREE.CubeRenderTarget(256);
    this.cubeRenderTarget.texture.type = THREE.HalfFloatType;
    this.cubeRenderTarget.texture.minFilter = THREE.LinearMipmapLinearFilter;
    this.cubeRenderTarget.texture.magFilter = THREE.LinearFilter;
    this.cubeRenderTarget.texture.generateMipmaps = true;

    this.cubeCamera = new THREE.CubeCamera(1, 1000, this.cubeRenderTarget);

    this.material = new THREE.MeshStandardNodeMaterial({
      envMap: this.cubeRenderTarget.texture,
      roughness: 0.05,
      metalness: 1
    });

    this.sphere = new THREE.Mesh(new THREE.IcosahedronGeometry(15, 8), this.material);
    core.render.scene.add(this.sphere);

    const material1 = new THREE.MeshStandardNodeMaterial({
      map: this.uvTexture,
      roughness: 0.1,
      metalness: 0,
    });

    const material2 = new THREE.MeshStandardNodeMaterial({
      map: this.uvTexture,
      roughness: 0.1,
      metalness: 0,
      envMap: this.texture,
    });

    this.cube = new THREE.Mesh(new THREE.BoxGeometry(15, 15, 15), material1);
    core.render.scene.add(this.cube);

    this.torus = new THREE.Mesh(new THREE.TorusKnotGeometry(8, 3, 128, 16), material2);
    core.render.scene.add(this.torus);

    const gui = core.render.renderer.inspector.createParameters('Settings');
    gui.add(this.material, 'roughness', 0, 1);
    gui.add(this.material, 'metalness', 0, 1);
    gui.add(core.render.renderer, 'toneMappingExposure', 0, 2).name('exposure');
    gui.add(core.render.scene, 'environmentIntensity', 0, 1);
    gui.add(material2, 'envMapIntensity', 0, 1);
  }

  /**
   * 组件卸载时调用：释放资源、取消订阅、清理监听器（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例，字段含义同 onMount
   */
  onUnmount(core) {

  }

  /**
   * 每帧更新回调：处理实时逻辑（运动、动画、碰撞检测、AI 等），会持续触发
   * @param {VD.Core} core 引擎核心实例。core.timer.getDelta() 可获取上一帧到当前的间隔秒数，常用于基于时间增量的位移 / 旋转
   */
  onUpdate(core) {
    const time = core.timer.getElapsed();

    this.cube.position.x = Math.cos(time) * 30;
    this.cube.position.y = Math.sin(time) * 30;
    this.cube.position.z = Math.sin(time) * 30;

    this.cube.rotation.x += 0.02;
    this.cube.rotation.y += 0.03;

    this.torus.position.x = Math.cos(time + 10) * 30;
    this.torus.position.y = Math.sin(time + 10) * 30;
    this.torus.position.z = Math.sin(time + 10) * 30;

    this.torus.rotation.x += 0.02;
    this.torus.rotation.y += 0.03;

    this.material.visible = false;

    this.cubeCamera.update(core.render.renderer, core.render.scene);

    this.material.visible = true;
  }
}