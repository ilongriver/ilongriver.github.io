
const amount = 10
const count = Math.pow(amount, 3);
const dummy = new THREE.Object3D();

class Script extends VD.Component {
  /**
   * @field
   * @type {THREE.BufferGeometry}
   */
  geometry
  /**
   * 组件挂载时调用：初始化资源、订阅事件、设置初始状态（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例。常用字段：core.timer（计时器）、core.render.scene（三维场景）、core.render.camera（当前相机）、core.container（DOM 容器）
   */
  onMount(core) {
    const { range, oscSine, time, mix, normalWorld } = TSL
    const material = new THREE.MeshBasicMaterial();

    // random colors between instances from 0x000000 to 0xFFFFFF
    const randomColors = range(new THREE.Color(0x000000), new THREE.Color(0xFFFFFF));

    material.colorNode = mix(normalWorld, randomColors, oscSine(time.mul(.1)));

    this.geometry.computeVertexNormals();
    this.geometry.scale(0.5, 0.5, 0.5);

    this.mesh = new THREE.InstancedMesh(this.geometry, material, count);
    this.mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);

    core.render.scene.add(this.mesh);

    //

    const gui = core.render.renderer.inspector.createParameters('Settings');
    gui.add(this.mesh, 'count', 1, count, 1).name('instance count');
  }

  /**
   * 组件卸载时调用：释放资源、取消订阅、清理监听器（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例，字段含义同 onMount
   */
  onUnmount(core) {

  }

  /**
   * 每帧更新回调：处理实时逻辑（运动、动画、碰撞检测、AI 等），会持续触发
   * @param {VD.Core} core 引擎核心实例。core.timer.getDelta() 可获取上一帧到当前的间隔秒数，常用于基于时间增量的位移 / 旋转
   */
  onUpdate(core) {
    const time = Date.now() * 0.001;

    this.mesh.rotation.x = Math.sin(time / 4);
    this.mesh.rotation.y = Math.sin(time / 2);

    let i = 0;
    const offset = (amount - 1) / 2;

    for (let x = 0; x < amount; x++) {

      for (let y = 0; y < amount; y++) {

        for (let z = 0; z < amount; z++) {

          dummy.position.set(offset - x, offset - y, offset - z);
          dummy.rotation.y = (Math.sin(x / 4 + time) + Math.sin(y / 4 + time) + Math.sin(z / 4 + time));
          dummy.rotation.z = dummy.rotation.y * 2;

          dummy.updateMatrix();

          this.mesh.setMatrixAt(i++, dummy.matrix);

        }

      }

    }
  }
}