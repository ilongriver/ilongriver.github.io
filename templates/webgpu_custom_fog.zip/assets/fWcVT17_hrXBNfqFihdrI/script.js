const { color, fog, positionWorld, triNoise3D, normalWorld, uniform, densityFogFactor } = TSL

const parameters = {
  elevation: 11, // sun height above the horizon, in degrees ( low = golden hour )
  azimuth: 150 // sun compass direction, in degrees
};

class Script extends VD.Component {
  /**
   * 组件挂载时调用：初始化资源、订阅事件、设置初始状态（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例。常用字段：core.timer（计时器）、core.render.scene（三维场景）、core.render.camera（当前相机）、core.container（DOM 容器）
   */
  onMount(core) {
    this.pmremGenerator = new THREE.PMREMGenerator(core.render.renderer);

    // a physical sky, used only to bake the image-based lighting ( it is not
    // the visible background — the fog gradient below is ); elevation / azimuth move the sun

    this.sky = new ADDONS.SkyMesh();
    this.sky.scale.setScalar(10000);
    this.sky.turbidity.value = 12;
    this.sky.rayleigh.value = 2;
    this.sky.mieCoefficient.value = 0.005;
    this.sky.mieDirectionalG.value = 0.88;

    this.sun = new THREE.Vector3();
    this.envScene = new THREE.Scene();

    // custom fog. an animated, two-octave triNoise3D haze that settles into
    // the valley as a level band: solid below `fogBase` ( down under the
    // mountains ) and fading out by `fogTop` ( around mid-height ), so the
    // peaks rise clear above it. the band sits at a fixed altitude whatever
    // the distance, and the noise wobbles its top edge and drifts it through
    // world space, so it reads as slow-moving cloud. ( the peaks reach ~130 )

    const skyColorValue = 0xf0f5f5;
    const groundColorValue = 0xd0dee7;

    const skyColor = color(skyColorValue);
    const groundColor = color(groundColorValue);

    const fogBase = uniform(- 20); // world-y the fog is solid below ( the valley floor )
    const fogTop = uniform(55); // world-y the fog fades out by ( mid-mountain )
    const haze = uniform(0.0012); // distance haze, so the far peaks dissolve into the same grey

    // a alternative way to create a TimerNode
    const time = uniform(0).onFrameUpdate((frame) => frame.time);

    const fogNoiseA = triNoise3D(positionWorld.mul(.005), 0.2, time);
    const fogNoiseB = triNoise3D(positionWorld.mul(.01), 0.2, time.mul(1.2));

    const fogNoise = fogNoiseA.add(fogNoiseB);

    // the noise lifts and drops the top of the band so it breaks into wisps
    const top = fogTop.add(fogNoise.sub(0.7).mul(22));
    const groundFogArea = top.sub(positionWorld.y).div(top.sub(fogBase)).saturate().mul(.98);

    // the valley band plus a distance haze, so the far peaks dissolve into the grey too
    const fogArea = groundFogArea.oneMinus().mul(densityFogFactor(haze).oneMinus()).oneMinus();

    core.render.scene.fogNode = fog(groundColor, fogArea);
    core.render.scene.backgroundNode = normalWorld.y.max(0).mix(groundColor, skyColor);

    // terrain + forest

    this.terrain = new ADDONS.TerrainGenerator({
      seed: 1,
      size: 900,
      segments: 512,
      frequency: 0.0065,
      heightScale: 150,
      erosion: 0.7,
      valleyBias: 1.2
    });

    this.forest = new ADDONS.ForestGenerator({ count: 500000, castShadow: true });

    this.generate();

    // a single directional key aligned with the sky's sun, for the crisp relief
    // shadows the sky fill alone can't give. its colour, intensity and position —
    // and the baked environment — are set by updateSun()

    this.sunLight = new THREE.DirectionalLight();
    this.sunLight.castShadow = true;
    this.sunLight.shadow.camera.left = - 420;
    this.sunLight.shadow.camera.right = 420;
    this.sunLight.shadow.camera.top = 420;
    this.sunLight.shadow.camera.bottom = - 420;
    this.sunLight.shadow.camera.near = 200;
    this.sunLight.shadow.camera.far = 1800;
    this.sunLight.shadow.mapSize.set(4096, 4096);
    this.sunLight.shadow.bias = - 0.0004;
    this.sunLight.shadow.normalBias = 0.15;
    this.sunLight.shadow.autoUpdate = false; // the scene is static — re-render the shadow map only when the sun moves ( see updateSun ), not every frame
    core.render.scene.add(this.sunLight);

    this.updateSun();

    // gui
    const gui = core.render.renderer.inspector.createParameters('Settings');

    const skyFolder = gui.addFolder('Sun');
    skyFolder.add(parameters, 'elevation', 1, 40).step(0.5).name('elevation').onChange(this.updateSun);
    skyFolder.add(parameters, 'azimuth', 0, 360).step(1).name('azimuth').onChange(this.updateSun);

    const fogFolder = gui.addFolder('Fog');
    fogFolder.add(fogBase, 'value', - 40, 20).step(1).name('base');
    fogFolder.add(fogTop, 'value', 0, 130).step(1).name('top');
    fogFolder.add(haze, 'value', 0, 0.005).step(0.0001).name('haze');

    const forestFolder = gui.addFolder('Forest');
    forestFolder.add(this.forest.from, 'value', 50, 1000).step(10).name('cull from');
    forestFolder.add(this.forest.to, 'value', 100, 1400).step(10).name('cull to');

    const terrainFolder = gui.addFolder('Terrain');
    terrainFolder.add(this.terrain.parameters, 'erosion', 0, 1.5).step(0.05).name('erosion');
    terrainFolder.add(this.terrain.parameters, 'valleyBias', 1, 3).step(0.1).name('valley bias');
    terrainFolder.add({ newSeed: this.newSeed }, 'newSeed').name('regenerate');
  }

  /**
   * 组件卸载时调用：释放资源、取消订阅、清理监听器（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例，字段含义同 onMount
   */
  onUnmount(core) {

  }

  /**
   * 每帧更新回调：处理实时逻辑（运动、动画、碰撞检测、AI 等），会持续触发
   * @param {VD.Core} core 引擎核心实例。core.timer.getDelta() 可获取上一帧到当前的间隔秒数，常用于基于时间增量的位移 / 旋转
   */
  onUpdate(core) {
    this.forest.setCameraPosition(core.render.camera.position); // drives the forest cull
  }

  // the forest sits on the terrain, so a new terrain means a new forest
  generate() {
    if (this.terrainGroup) this.core.render.scene.remove(this.terrainGroup);
    if (this.forestGroup) this.core.render.scene.remove(this.forestGroup);

    this.terrainGroup = this.terrain.build();
    this.forestGroup = this.forest.build(this.terrain);

    this.forestGroup.children[0].raycast = () => {} // 解决射线检测性能问题

    this.core.render.scene.add(this.terrainGroup);
    this.core.render.scene.add(this.forestGroup);

    if (this.sunLight) this.sunLight.shadow.needsUpdate = true; // rebuilt geometry ⇒ re-render the shadow map ( skipped on the first build, before the light exists; updateSun covers it )
  }

  // walks the sun: aligns the sky and the key light ( warm and dim near the
  // horizon ), then re-bakes the sky into the IBL environment
  updateSun = () => {
    const elevation = parameters.elevation;

    this.sun.setFromSphericalCoords(1, THREE.MathUtils.degToRad(90 - elevation), THREE.MathUtils.degToRad(parameters.azimuth));
    this.sky.sunPosition.value.copy(this.sun);

    // the longer air path near the horizon dims and warms the sun. it stays
    // far brighter than the sky fill, so it reads as the key and casts firm shadows
    const transmittance = Math.sqrt(Math.max(Math.sin(THREE.MathUtils.degToRad(elevation)), 0));
    this.sunLight.color.set(0xff7a2f).lerp(new THREE.Color(0xfff2e0), transmittance); // deep orange → warm white
    this.sunLight.intensity = 11 * transmittance + 0.3;
    this.sunLight.position.copy(this.sun).multiplyScalar(900);
    this.sunLight.shadow.needsUpdate = true; // the sun moved, so the on-demand shadow map needs one refresh

    // re-bake the sky ( without the sun disc ) into the environment map for IBL.
    // the sky lives only in envScene; it is never added to the visible scene
    this.sky.showSunDisc.value = false;
    this.envScene.add(this.sky);
    const env = this.pmremGenerator.fromScene(this.envScene).texture;
    if (this.core.render.scene.environment) this.core.render.scene.environment.dispose();
    this.core.render.scene.environment = env;
  }

  // a new seed ( and whatever erosion / valley bias is dialled in ) rebuilds
  // the terrain, and with it the forest that sits on top
  newSeed = () => {
    this.terrain.parameters.seed++;
    this.generate();
  }
}