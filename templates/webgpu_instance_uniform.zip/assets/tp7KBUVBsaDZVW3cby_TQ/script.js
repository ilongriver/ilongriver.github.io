const { uniform, pmremTexture, normalWorld } = TSL

class InstanceUniformNode extends THREE.Node {

  constructor() {

    super('vec3');

    this.updateType = THREE.NodeUpdateType.OBJECT;

    this.uniformNode = uniform(new THREE.Color());

  }

  update(frame) {

    const mesh = frame.object;

    const meshColor = mesh.color;

    this.uniformNode.value.copy(meshColor);

  }

  setup( /*builder*/) {

    return this.uniformNode;

  }

}

const objects = [];

class Script extends VD.Component {
  /**
   * @field
   * @type {THREE.Texture}
   */
  cTexture
  /**
   * 组件挂载时调用：初始化资源、订阅事件、设置初始状态（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例。常用字段：core.timer（计时器）、core.render.scene（三维场景）、core.render.camera（当前相机）、core.container（DOM 容器）
   */
  onMount(core) {
    // Grid

    const helper = new THREE.GridHelper(1000, 40, 0x303030, 0x303030);
    helper.position.y = - 75;
    core.render.scene.add(helper);

    // Materials

    const instanceUniform = new InstanceUniformNode();
    // 使用 texture 节点替代 pmremTexture，用世界坐标方向采样 equirectangular 环境贴图
    const cubeTextureNode = pmremTexture(this.cTexture, normalWorld, uniform(0));

    const material = new THREE.MeshBasicNodeMaterial();
    material.colorNode = instanceUniform.add(cubeTextureNode);
    material.emissiveNode = instanceUniform.mul(cubeTextureNode);

    // Geometry

    const geometry = new ADDONS.TeapotGeometry(50, 18);

    for (let i = 0, l = 12; i < l; i++) {

      this.addMesh(geometry, material);

    }
  }

  /**
   * 组件卸载时调用：释放资源、取消订阅、清理监听器（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例，字段含义同 onMount
   */
  onUnmount(core) {

  }

  /**
   * 每帧更新回调：处理实时逻辑（运动、动画、碰撞检测、AI 等），会持续触发
   * @param {VD.Core} core 引擎核心实例。core.timer.getDelta() 可获取上一帧到当前的间隔秒数，常用于基于时间增量的位移 / 旋转
   */
  onUpdate(core) {
    for (let i = 0, l = objects.length; i < l; i++) {

      const object = objects[i];

      object.rotation.x += 0.01;
      object.rotation.y += 0.005;

    }
  }

  addMesh(geometry, material) {

    const mesh = new THREE.Mesh(geometry, material);

    mesh.color = new THREE.Color(Math.random() * 0xffffff);

    mesh.position.x = (objects.length % 4) * 200 - 300;
    mesh.position.z = Math.floor(objects.length / 4) * 200 - 200;

    mesh.rotation.x = Math.random() * 200 - 100;
    mesh.rotation.y = Math.random() * 200 - 100;
    mesh.rotation.z = Math.random() * 200 - 100;

    objects.push(mesh);

    this.core.render.scene.add(mesh);

  }
}