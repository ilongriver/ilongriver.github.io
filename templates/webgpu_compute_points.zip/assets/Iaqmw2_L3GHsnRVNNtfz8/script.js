const { Fn, uniform, instancedArray, float, vec2, color, instanceIndex } = TSL

const pointerVector = new THREE.Vector2(- 10.0, - 10.0); // Out of bounds first
const scaleVector = new THREE.Vector2(1, 1);

class Script extends VD.Component {
  /**
   * 组件挂载时调用：初始化资源、订阅事件、设置初始状态（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例。常用字段：core.timer（计时器）、core.render.scene（三维场景）、core.render.camera（当前相机）、core.container（DOM 容器）
   */
  onMount(core) {
    // initialize particles

    const particlesCount = 300000;

    const particleArray = instancedArray(particlesCount, 'vec2');
    const velocityArray = instancedArray(particlesCount, 'vec2');

    // create function

    const computeShaderFn = Fn(() => {

      const particle = particleArray.element(instanceIndex);
      const velocity = velocityArray.element(instanceIndex);

      const pointer = uniform(pointerVector);
      const limit = uniform(scaleVector);

      const position = particle.add(velocity).toVar();

      velocity.x = position.x.abs().greaterThanEqual(limit.x).select(velocity.x.negate(), velocity.x);
      velocity.y = position.y.abs().greaterThanEqual(limit.y).select(velocity.y.negate(), velocity.y);

      position.assign(position.min(limit).max(limit.negate()));

      const pointerSize = 0.1;
      const distanceFromPointer = pointer.sub(position).length();

      particle.assign(distanceFromPointer.lessThanEqual(pointerSize).select(vec2(), position));

    });

    // compute

    this.computeNode = computeShaderFn().compute(particlesCount).setName('Update Particles');
    this.computeNode.onInit(({ renderer }) => {

      const precomputeShaderNode = Fn(() => {

        const particleIndex = float(instanceIndex);

        const randomAngle = particleIndex.mul(.005).mul(Math.PI * 2);
        const randomSpeed = particleIndex.mul(0.00000001).add(0.0000001);

        const velX = randomAngle.sin().mul(randomSpeed);
        const velY = randomAngle.cos().mul(randomSpeed);

        const velocity = velocityArray.element(instanceIndex);

        velocity.xy = vec2(velX, velY);

      });

      core.render.renderer.compute(precomputeShaderNode().compute(particlesCount));

    });

    // use a compute shader to animate the point cloud's vertex data.

    const pointsGeometry = new THREE.BufferGeometry();
    pointsGeometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(3), 3)); // single vertex ( not triangle )
    pointsGeometry.drawRange.count = 1; // force render points as instances ( not triangle )

    const pointsMaterial = new THREE.PointsNodeMaterial();
    pointsMaterial.colorNode = particleArray.element(instanceIndex).add(color(0xFFFFFF));
    pointsMaterial.positionNode = particleArray.element(instanceIndex);

    const mesh = new THREE.Points(pointsGeometry, pointsMaterial);
    mesh.count = particlesCount;
    core.render.scene.add(mesh);

    window.addEventListener('mousemove', this.onMouseMove);

    // gui

    const gui = core.render.renderer.inspector.createParameters('Settings');

    gui.add(scaleVector, 'x', 0, 1, 0.01);
    gui.add(scaleVector, 'y', 0, 1, 0.01);
  }

  onMouseMove = (event) => {

    const x = event.clientX;
    const y = event.clientY;

    const width = window.innerWidth;
    const height = window.innerHeight;

    pointerVector.set(
      (x / width - 0.5) * 2.0,
      (- y / height + 0.5) * 2.0
    );

  }

  /**
   * 组件卸载时调用：释放资源、取消订阅、清理监听器（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例，字段含义同 onMount
   */
  onUnmount(core) {

  }

  /**
   * 每帧更新回调：处理实时逻辑（运动、动画、碰撞检测、AI 等），会持续触发
   * @param {VD.Core} core 引擎核心实例。core.timer.getDelta() 可获取上一帧到当前的间隔秒数，常用于基于时间增量的位移 / 旋转
   */
  onUpdate(core) {
    core.render.renderer.compute(this.computeNode);
  }
}