let probes, probesHelper;

class Script extends VD.Component {
  /**
   * 组件挂载时调用：初始化资源、订阅事件、设置初始状态（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例。常用字段：core.timer（计时器）、core.render.scene（三维场景）、core.render.camera（当前相机）、core.container（DOM 容器）
   */
  async onMount(core) {
    const { scene, renderer } = core.render
    // Cornell box

    const wallMaterial = new THREE.MeshStandardMaterial({ color: 0xcccccc });
    const redMaterial = new THREE.MeshStandardMaterial({ color: 0xff0000 });
    const greenMaterial = new THREE.MeshStandardMaterial({ color: 0x00ff00 });

    // Floor
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(6, 6), wallMaterial);
    floor.rotation.x = - Math.PI / 2;
    floor.receiveShadow = true;
    scene.add(floor);

    // Ceiling
    const ceiling = new THREE.Mesh(new THREE.PlaneGeometry(6, 6), wallMaterial);
    ceiling.rotation.x = Math.PI / 2;
    ceiling.position.y = 5;
    ceiling.receiveShadow = true;
    scene.add(ceiling);

    // Back wall
    const backWall = new THREE.Mesh(new THREE.PlaneGeometry(6, 5), wallMaterial);
    backWall.position.set(0, 2.5, - 3);
    backWall.receiveShadow = true;
    scene.add(backWall);

    // Front wall
    const frontWall = new THREE.Mesh(new THREE.PlaneGeometry(6, 5), wallMaterial);
    frontWall.rotation.y = Math.PI;
    frontWall.position.set(0, 2.5, 3);
    frontWall.receiveShadow = true;
    scene.add(frontWall);

    // Left wall (red)
    const leftWall = new THREE.Mesh(new THREE.PlaneGeometry(6, 5), redMaterial);
    leftWall.rotation.y = Math.PI / 2;
    leftWall.position.set(- 3, 2.5, 0);
    leftWall.receiveShadow = true;
    scene.add(leftWall);

    // Right wall (green)
    const rightWall = new THREE.Mesh(new THREE.PlaneGeometry(6, 5), greenMaterial);
    rightWall.rotation.y = - Math.PI / 2;
    rightWall.position.set(3, 2.5, 0);
    rightWall.receiveShadow = true;
    scene.add(rightWall);

    // Objects inside the box

    const objectMaterial = new THREE.MeshStandardMaterial({ color: 0xeeeeee });

    // Tall box
    const tallBox = new THREE.Mesh(new THREE.BoxGeometry(1.2, 2.5, 1.2), objectMaterial);
    tallBox.position.set(- 0.8, 1.25, - 0.8);
    tallBox.rotation.y = Math.PI / 8;
    tallBox.castShadow = true;
    tallBox.receiveShadow = true;
    scene.add(tallBox);

    // Short box
    const shortBox = new THREE.Mesh(new THREE.BoxGeometry(1.2, 1.2, 1.2), objectMaterial);
    shortBox.position.set(1, 0.6, 0.5);
    shortBox.rotation.y = - Math.PI / 6;
    shortBox.castShadow = true;
    shortBox.receiveShadow = true;
    scene.add(shortBox);

    // Sphere (to show smooth GI variation)
    const sphere = new THREE.Mesh(new THREE.SphereGeometry(0.5, 32, 32), objectMaterial.clone());
    sphere.position.set(1, 1.9, 0.5);
    sphere.castShadow = true;
    sphere.receiveShadow = true;
    scene.add(sphere);

    // Light
    const light = new THREE.PointLight(0xffffff, 40);
    light.position.set(0, 4.5, 0);
    light.castShadow = true;
    light.shadow.mapSize.setScalar(256);
    light.shadow.radius = 10;
    light.shadow.normalBias = - 0.02;
    scene.add(light);

    // Bake light probe volume

    async function bake(resolution) {

      if (probes) {

        scene.remove(probes);
        probes.dispose();

      }

      probes = new ADDONS.LightProbeGrid(5.6, 4.7, 5.6, resolution, resolution, resolution);
      probes.position.set(0, 2.45, 0);
      await probes.bake(renderer, scene, { cubemapSize: 32, near: 0.05, far: 20 });
      probes.visible = params.enabled;
      scene.add(probes);

      // Update debug visualization

      if (!probesHelper) {

        probesHelper = new ADDONS.LightProbeGridHelper(probes);
        probesHelper.visible = params.showProbes;
        scene.add(probesHelper);

      } else {

        probesHelper.probes = probes;
        probesHelper.update();

      }

    }

    const params = {
      enabled: true,
      showProbes: false,
      resolution: 6
    };

    await bake(params.resolution);

    // GUI

    const gui = renderer.inspector.createParameters('Light Probes');
    gui.add(params, 'enabled').name('GI').onChange((value) => {

      probes.visible = value;

    });

    gui.add(params, 'resolution', 2, 12, 1).name('Resolution').onChange((value) => {

      bake(value);

    }).debounce(250);
    gui.add(params, 'showProbes').name('Show Probes').onChange((value) => {

      probesHelper.visible = value;

    });
  }

  /**
   * 组件卸载时调用：释放资源、取消订阅、清理监听器（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例，字段含义同 onMount
   */
  onUnmount(core) {

  }

  /**
   * 每帧更新回调：处理实时逻辑（运动、动画、碰撞检测、AI 等），会持续触发
   * @param {VD.Core} core 引擎核心实例。core.timer.getDelta() 可获取上一帧到当前的间隔秒数，常用于基于时间增量的位移 / 旋转
   */
  onUpdate(core) {

  }
}