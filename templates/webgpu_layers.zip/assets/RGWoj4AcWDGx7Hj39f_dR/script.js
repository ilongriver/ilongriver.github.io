const { positionLocal, time, mod, instancedBufferAttribute, rotate, screenUV, color, vec2 } = TSL

class Script extends VD.Component {
  /**
   * @field
   * @type {THREE.Texture}
   */
  sprite
  /**
   * 组件挂载时调用：初始化资源、订阅事件、设置初始状态（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例。常用字段：core.timer（计时器）、core.render.scene（三维场景）、core.render.camera（当前相机）、core.container（DOM 容器）
   */
  onMount(core) {
    const { camera, scene, renderer } = core.render

    camera.layers.enable(0); // enabled by default
    camera.layers.enable(1);
    camera.layers.enable(2);

    const horizontalEffect = screenUV.x.mix(color(0xf996ae), color(0xf6f0a3));
    const lightEffect = screenUV.distance(vec2(0.5, 1.0)).oneMinus().mul(color(0xd9b6fd));

    scene.backgroundNode = horizontalEffect.add(lightEffect);

    const count = 2500;

    const geometry = new THREE.PlaneGeometry(0.25, 0.25);

    const colors = [0xD70654, 0xFFD95F, 0xB8D576];

    for (let i = 0; i < 3; i++) {

      const particles = new THREE.Mesh(geometry, this.getMaterial(count, colors[i], this.sprite));
      particles.layers.set(i);
      particles.count = count;
      scene.add(particles);

    }

    // GUI

    const layers = {
      'Red': true,
      'Yellow': true,
      'Green': true
    };

    const gui = renderer.inspector.createParameters('Layers');

    gui.add(layers, 'Red').onChange(() => {

      camera.layers.toggle(0);

    });

    gui.add(layers, 'Yellow').onChange(() => {

      camera.layers.toggle(1);

    });

    gui.add(layers, 'Green').onChange(() => {

      camera.layers.toggle(2);

    });
  }

  /**
   * 组件卸载时调用：释放资源、取消订阅、清理监听器（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例，字段含义同 onMount
   */
  onUnmount(core) {

  }

  /**
   * 每帧更新回调：处理实时逻辑（运动、动画、碰撞检测、AI 等），会持续触发
   * @param {VD.Core} core 引擎核心实例。core.timer.getDelta() 可获取上一帧到当前的间隔秒数，常用于基于时间增量的位移 / 旋转
   */
  onUpdate(core) {

  }

  getMaterial(count, color, sprite) {

    // instance data

    const positions = [];
    const rotations = [];
    const directions = [];
    const timeOffsets = [];

    const v = new THREE.Vector3();

    for (let i = 0; i < count; i++) {

      positions.push(
        THREE.MathUtils.randFloat(- 25, - 20),
        THREE.MathUtils.randFloat(- 10, 50),
        THREE.MathUtils.randFloat(- 5, 5)
      );

      v.set(THREE.MathUtils.randFloat(0.7, 0.9), THREE.MathUtils.randFloat(- 0.3, - 0.15), 0).normalize();

      rotations.push(Math.random(), Math.random(), Math.random());

      directions.push(v.x, v.y, v.z);

      timeOffsets.push(i / count);

    }

    const positionAttribute = new THREE.InstancedBufferAttribute(new Float32Array(positions), 3);
    const rotationAttribute = new THREE.InstancedBufferAttribute(new Float32Array(rotations), 3);
    const directionAttribute = new THREE.InstancedBufferAttribute(new Float32Array(directions), 3);
    const timeAttribute = new THREE.InstancedBufferAttribute(new Float32Array(timeOffsets), 1);

    // material

    const material = new THREE.MeshBasicNodeMaterial({
      color: color,
      map: sprite,
      alphaMap: sprite,
      alphaTest: 0.1,
      side: THREE.DoubleSide,
      forceSinglePass: true
    });

    // TSL

    const instancePosition = instancedBufferAttribute(positionAttribute);
    const instanceDirection = instancedBufferAttribute(directionAttribute);
    const instanceRotation = instancedBufferAttribute(rotationAttribute);

    const localTime = instancedBufferAttribute(timeAttribute).add(time.mul(0.02));
    const modTime = mod(localTime, 1.0);

    const rotatedPosition = rotate(positionLocal, instanceRotation.mul(modTime.mul(20)));
    material.positionNode = rotatedPosition.add(instancePosition).add(instanceDirection.mul(modTime.mul(50)));

    return material;

  }

}