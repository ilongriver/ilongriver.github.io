class Script extends VD.Component {
  /**
   * @field
   * @type {'方案1' | '方案2' | '方案3'}
   */
  mode = '方案1'
  /**
   * @field
   * @type {number}
   */
  count = 0
  /**
   * 组件挂载时调用：初始化资源、订阅事件、设置初始状态（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例。常用字段：core.timer（计时器）、core.render.scene（三维场景）、core.render.camera（当前相机）、core.container（DOM 容器）
   */
  onMount(core) {
    const modes = {
      方案1: '方案1',
      方案2: '方案2',
      方案3: '方案3',
    }

    const gui = core.render.renderer.inspector.createParameters('Settings');

    gui.add(this, 'mode', Object.keys(modes)).onChange(name => {
      this.mode = modes[name];
    });

    console.log(this.mode)
    console.log(this.count)
  }

  /**
   * 组件卸载时调用：释放资源、取消订阅、清理监听器（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例，字段含义同 onMount
   */
  onUnmount(core) {

  }

  /**
   * 每帧更新回调：处理实时逻辑（运动、动画、碰撞检测、AI 等），会持续触发
   * @param {VD.Core} core 引擎核心实例。core.timer.getDelta() 可获取上一帧到当前的间隔秒数，常用于基于时间增量的位移 / 旋转
   */
  onUpdate(core) {
    const { camera } = core.render

    if (this.mode === '方案1') {
      this.object.quaternion.copy(camera.quaternion)
    } else if (this.mode === '方案2') {
      this.object.lookAt(camera.position)
    } else if (this.mode === '方案3') {
      const dx = camera.position.x - this.object.position.x
      const dz = camera.position.z - this.object.position.z

      // Y 轴旋转，使 Z 轴朝向相机
      this.object.rotation.y = Math.atan2(dx, dz)
    }
  }
}