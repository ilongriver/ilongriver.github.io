const { color, lights } = TSL

class CustomLightingModel extends THREE.LightingModel {

  direct({ lightColor, reflectedLight }/*, builder */) {

    reflectedLight.directDiffuse.addAssign(lightColor);

  }

}

let light1, light2, light3;

class Script extends VD.Component {
  /**
   * 组件挂载时调用：初始化资源、订阅事件、设置初始状态（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例。常用字段：core.timer（计时器）、core.render.scene（三维场景）、core.render.camera（当前相机）、core.container（DOM 容器）
   */
  onMount(core) {
    const { scene } = core.render
    // lights

    const sphereGeometry = new THREE.SphereGeometry(0.02, 16, 8);

    const addLight = (hexColor) => {

      const material = new THREE.NodeMaterial();
      material.colorNode = color(hexColor);
      material.lightsNode = lights(); // ignore scene lights

      const mesh = new THREE.Mesh(sphereGeometry, material);

      const light = new THREE.PointLight(hexColor, 0.1, 1);
      light.add(mesh);

      scene.add(light);

      return light;

    };

    light1 = addLight(0xffaa00);
    light2 = addLight(0x0040ff);
    light3 = addLight(0x80ff80);

    //light nodes ( selective lights )

    const allLightsNode = lights([light1, light2, light3]);

    // points

    const points = [];

    for (let i = 0; i < 500000; i++) {

      const point = new THREE.Vector3().random().subScalar(0.5).multiplyScalar(3);
      points.push(point);

    }

    const geometryPoints = new THREE.BufferGeometry().setFromPoints(points);
    const materialPoints = new THREE.PointsNodeMaterial();

    // custom lighting model

    const lightingModel = new CustomLightingModel();
    const lightingModelContext = allLightsNode.context({ lightingModel });

    materialPoints.lightsNode = lightingModelContext;

    //

    const pointCloud = new THREE.Points(geometryPoints, materialPoints);
    pointCloud.raycast = () => {}
    scene.add(pointCloud);
  }

  /**
   * 组件卸载时调用：释放资源、取消订阅、清理监听器（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例，字段含义同 onMount
   */
  onUnmount(core) {

  }

  /**
   * 每帧更新回调：处理实时逻辑（运动、动画、碰撞检测、AI 等），会持续触发
   * @param {VD.Core} core 引擎核心实例。core.timer.getDelta() 可获取上一帧到当前的间隔秒数，常用于基于时间增量的位移 / 旋转
   */
  onUpdate(core) {
    const { scene } = core.render

    const time = Date.now() * 0.001;
    const scale = .5;

    light1.position.x = Math.sin(time * 0.7) * scale;
    light1.position.y = Math.cos(time * 0.5) * scale;
    light1.position.z = Math.cos(time * 0.3) * scale;

    light2.position.x = Math.cos(time * 0.3) * scale;
    light2.position.y = Math.sin(time * 0.5) * scale;
    light2.position.z = Math.sin(time * 0.7) * scale;

    light3.position.x = Math.sin(time * 0.7) * scale;
    light3.position.y = Math.cos(time * 0.3) * scale;
    light3.position.z = Math.sin(time * 0.5) * scale;

    scene.rotation.y = time * 0.1;
  }
}