const GRID = 30; // GRID x GRID spheres
const SPACING = 5;
const RADIUS = 0.5;
const WAVE_HEIGHT = 4;
const BIG_RADIUS = 6;
const BASE_POWER = 45;

let spheresMesh, lighting;
let renderPipeline, scenePass, clusterInfluence, debugZSliceNode;

const balls = [];
const dummy = new THREE.Object3D();

const params = {
  intensity: 1,
  animate: true
};

const { instancedBufferAttribute, pass, uniform, vec3, float, mix, step, renderOutput } = TSL

class Script extends VD.Component {
  /**
   * 组件挂载时调用：初始化资源、订阅事件、设置初始状态（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例。常用字段：core.timer（计时器）、core.render.scene（三维场景）、core.render.camera（当前相机）、core.container（DOM 容器）
   */
  onMount(core) {
    const { renderer, scene, pipeline, camera } = core.render

    lighting = new ADDONS.ClusteredLighting();
    renderer.lighting = lighting; // set lighting system

    // ground

    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(1000, 1000).rotateX(- Math.PI / 2),
      new THREE.MeshPhongNodeMaterial({ color: 0x2a2a2a, shininess: 80 })
    );
    scene.add(ground);

    // four big spheres in the middle for the surrounding lights to play across

    const bigPositions = [
      new THREE.Vector3(- 9, BIG_RADIUS, - 9),
      new THREE.Vector3(9, BIG_RADIUS, - 9),
      new THREE.Vector3(- 9, BIG_RADIUS, 9),
      new THREE.Vector3(9, BIG_RADIUS, 9)
    ];

    const bigGeometry = new THREE.SphereGeometry(BIG_RADIUS, 64, 32);
    const bigMaterial = new THREE.MeshPhongNodeMaterial({ color: 0xdddddd, shininess: 80 });

    for (const position of bigPositions) {

      const bigSphere = new THREE.Mesh(bigGeometry, bigMaterial);
      bigSphere.position.copy(position);
      scene.add(bigSphere);

    }

    // a grid of coloured spheres drawn as a single InstancedMesh; each is
    // unlit in its own colour and holds a matching point light at its centre

    const maxCount = GRID * GRID;
    const colorAttribute = new THREE.InstancedBufferAttribute(new Float32Array(maxCount * 3), 3);

    const material = new THREE.MeshBasicNodeMaterial();
    material.colorNode = instancedBufferAttribute(colorAttribute);

    spheresMesh = new THREE.InstancedMesh(new THREE.SphereGeometry(RADIUS, 32, 16), material, maxCount);
    spheresMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    scene.add(spheresMesh);

    const color = new THREE.Color();
    const span = (GRID - 1) * SPACING;

    let i = 0;

    for (let ix = 0; ix < GRID; ix++) {

      for (let iz = 0; iz < GRID; iz++) {

        const x = ix * SPACING - span / 2;
        const z = iz * SPACING - span / 2;

        // leave a clearing where a big sphere sits
        if (bigPositions.some((position) => Math.hypot(x - position.x, z - position.z) < BIG_RADIUS + 1)) continue;

        const phase = (ix + iz) * 0.5;

        dummy.position.set(x, RADIUS, z);
        dummy.updateMatrix();
        spheresMesh.setMatrixAt(i, dummy.matrix);

        color.setHSL((ix * GRID + iz) / (GRID * GRID), 1.0, 0.5);
        colorAttribute.setXYZ(i, color.r, color.g, color.b);

        const light = new THREE.PointLight(color, 1, 9);
        light.power = BASE_POWER;
        light.position.set(x, RADIUS, z);
        scene.add(light);

        balls.push({ x, z, phase, light });

        i++;

      }

    }

    spheresMesh.count = i;

    // post-processing: a debug overlay that tints each screen tile by how many
    // lights its cluster holds, for the selected depth slice
    scenePass = pass(scene, camera);
    clusterInfluence = uniform(0);

    debugZSliceNode = uniform(20, 'int');

    renderPipeline = pipeline;
    renderPipeline.outputColorTransform = false;

    this.updatePostProcessing()

    // gui

    const gui = renderer.inspector.createParameters('Settings');
    gui.add(params, 'intensity', 0, 3).name('light intensity').onChange((value) => {

      for (const ball of balls) ball.light.power = BASE_POWER * value;

    });
    gui.add(params, 'animate');
    gui.add(clusterInfluence, 'value', 0, .7).name('lights per tile');
    gui.add(debugZSliceNode, 'value', 0, lighting.zSlices - 1, 1).name('z-slice');

  }

  onResize() {
    this.updatePostProcessing()
  }

  /**
   * 组件卸载时调用：释放资源、取消订阅、清理监听器（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例，字段含义同 onMount
   */
  onUnmount(core) {

  }

  /**
   * 每帧更新回调：处理实时逻辑（运动、动画、碰撞检测、AI 等），会持续触发
   * @param {VD.Core} core 引擎核心实例。core.timer.getDelta() 可获取上一帧到当前的间隔秒数，常用于基于时间增量的位移 / 旋转
   */
  onUpdate(core) {
    if (params.animate === true) {

      const time = performance.now() / 1000;

      for (let i = 0; i < balls.length; i++) {

        const ball = balls[i];
        const y = RADIUS + (0.5 + 0.5 * Math.sin(time * 1.5 + ball.phase)) * WAVE_HEIGHT;

        dummy.position.set(ball.x, y, ball.z);
        dummy.updateMatrix();
        spheresMesh.setMatrixAt(i, dummy.matrix);

        ball.light.position.y = y;

      }

      spheresMesh.instanceMatrix.needsUpdate = true;

    }
  }

  updatePostProcessing() {
    const { scene } = this.core.render
    // the overlay samples the cluster grid at the current resolution, so it
    // is rebuilt whenever the renderer size changes

    const lightingNode = lighting.getNode(scene).setSize(window.innerWidth * window.devicePixelRatio, window.innerHeight * window.devicePixelRatio);

    // map the light count of each cluster ( 0 … maxLightsPerCluster ) to a
    // blue → green → red gradient
    const lightCount = lightingNode.getClusterLightCount(debugZSliceNode);
    const heatmap = float(lightCount).div(float(lighting.maxLightsPerCluster));

    let heatColor = mix(vec3(0.0, 0.0, 1.0), vec3(0.0, 1.0, 0.0), heatmap.mul(2.0).saturate());
    heatColor = mix(heatColor, vec3(1.0, 0.0, 0.0), heatmap.sub(0.5).mul(2.0).saturate());

    // blend the heatmap over the scene by the slider amount; step() keeps
    // empty clusters transparent
    const finalInfluence = clusterInfluence.mul(step(0.0001, heatmap));

    const outputPass = renderOutput(mix(scenePass, heatColor, finalInfluence));

    renderPipeline.outputNode = ADDONS.fxaa(outputPass);
    renderPipeline.needsUpdate = true;

  }
}