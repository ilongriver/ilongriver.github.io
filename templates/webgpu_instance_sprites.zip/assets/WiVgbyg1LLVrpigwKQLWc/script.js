const { uniform, time, instanceIndex, instancedBufferAttribute } = TSL

class Script extends VD.Component {
  /**
   * @field
   * @type {THREE.Texture}
   */
  map
  /**
   * 组件挂载时调用：初始化资源、订阅事件、设置初始状态（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例。常用字段：core.timer（计时器）、core.render.scene（三维场景）、core.render.camera（当前相机）、core.container（DOM 容器）
   */
  onMount(core) {
    // positions

    const count = 10000;

    const positions = [];

    for (let i = 0; i < count; i++) {

      positions.push(2000 * Math.random() - 1000, 2000 * Math.random() - 1000, 2000 * Math.random() - 1000);

    }

    const positionAttribute = new THREE.InstancedBufferAttribute(new Float32Array(positions), 3);

    // material

    this.material = new THREE.SpriteNodeMaterial({ sizeAttenuation: true, map: this.map, alphaMap: this.map, alphaTest: 0.1 });
    this.material.color.setHSL(1.0, 0.3, 0.7, THREE.SRGBColorSpace);
    this.material.positionNode = instancedBufferAttribute(positionAttribute);
    this.material.rotationNode = time.add(instanceIndex).sin();
    this.material.scaleNode = uniform(15);

    // sprites

    const particles = new THREE.Sprite(this.material);
    particles.count = count;

    core.render.scene.add(particles);

    const gui = core.render.renderer.inspector.createParameters('Settings');

    gui.add(this.material, 'sizeAttenuation').onChange(() => {

      this.material.needsUpdate = true;
      this.material.scaleNode.value = this.material.sizeAttenuation ? 15 : 0.03;

    });

    //
    this.mouseX = 0
    this.mouseY = 0;

    this.windowHalfX = window.innerWidth / 2;
    this.windowHalfY = window.innerHeight / 2;

    document.body.style.touchAction = 'none';
    document.body.addEventListener('pointermove', this._onPointerMove);
  }

  /**
   * 组件卸载时调用：释放资源、取消订阅、清理监听器（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例，字段含义同 onMount
   */
  onUnmount(core) {

  }

  /**
   * 每帧更新回调：处理实时逻辑（运动、动画、碰撞检测、AI 等），会持续触发
   * @param {VD.Core} core 引擎核心实例。core.timer.getDelta() 可获取上一帧到当前的间隔秒数，常用于基于时间增量的位移 / 旋转
   */
  onUpdate(core) {
    const { camera, scene } = core.render

    const time = Date.now() * 0.00005;

    camera.position.x += (this.mouseX - camera.position.x) * 0.05;
    camera.position.y += (- this.mouseY - camera.position.y) * 0.05;

    camera.lookAt(scene.position);

    const h = (360 * (1.0 + time) % 360) / 360;
    this.material.color.setHSL(h, 0.5, 0.5);
  }

  onResize() {
    this.windowHalfX = window.innerWidth / 2;
    this.windowHalfY = window.innerHeight / 2;
  }

  _onPointerMove = (event) => {

    if (event.isPrimary === false) return;

    this.mouseX = event.clientX - this.windowHalfX;
    this.mouseY = event.clientY - this.windowHalfY;

  }
}