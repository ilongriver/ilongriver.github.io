const { uniform, mix, pmremTexture, reference, positionLocal, hue, saturation, positionWorld, normalWorld, positionWorldDirection, positionViewDirection, reflectVector } = TSL

class Script extends VD.Component {
  /**
   * @field
   * @type {THREE.Texture}
   */
  hdr1Texture
  /**
   * @field
   * @type {THREE.Texture}
   */
  hdr2Texture
  /**
   * 组件挂载时调用：初始化资源、订阅事件、设置初始状态（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例。常用字段：core.timer（计时器）、core.render.scene（三维场景）、core.render.camera（当前相机）、core.container（DOM 容器）
   */
  onMount(core) {
    // nodes and environment

    const adjustments = {
      mix: 0,
      procedural: 0,
      intensity: 1,
      hue: 0,
      saturation: 1
    };

    const mixNode = reference('mix', 'float', adjustments);
    const proceduralNode = reference('procedural', 'float', adjustments);
    const intensityNode = reference('intensity', 'float', adjustments);
    const hueNode = reference('hue', 'float', adjustments);
    const saturationNode = reference('saturation', 'float', adjustments);

    const rotateY1Matrix = new THREE.Matrix4();
    const rotateY2Matrix = new THREE.Matrix4();

    const getEnvironmentNode = (reflectNode, positionNode) => {
      const custom1UV = reflectNode.xyz.mul(uniform(rotateY1Matrix));
      const custom2UV = reflectNode.xyz.mul(uniform(rotateY2Matrix));
      const mixCubeMaps = mix(pmremTexture(this.hdr1Texture, custom1UV), pmremTexture(this.hdr2Texture, custom2UV), positionNode.y.add(mixNode).clamp());

      const proceduralEnv = mix(mixCubeMaps, normalWorld, proceduralNode);

      const intensityFilter = proceduralEnv.mul(intensityNode);
      const hueFilter = hue(intensityFilter, hueNode);
      return saturation(hueFilter, saturationNode);
    };

    const blurNode = uniform(0);

    core.render.scene.environmentNode = getEnvironmentNode(reflectVector, positionWorld);

    core.render.scene.backgroundNode = getEnvironmentNode(positionWorldDirection, positionLocal).context({
      getTextureLevel: () => blurNode
    });

    const sphereGeometry = new THREE.SphereGeometry(.5, 64, 32);

    const sphereRightView = new THREE.Mesh(sphereGeometry, new THREE.MeshStandardMaterial({ roughness: 0, metalness: 1 }));
    sphereRightView.position.x += 2;

    const sphereLeftView = new THREE.Mesh(sphereGeometry, new THREE.MeshStandardMaterial({ roughness: 1, metalness: 1 }));
    sphereLeftView.position.x -= 2;

    core.render.scene.add(sphereLeftView);
    core.render.scene.add(sphereRightView);

    // gui

    const gui = core.render.renderer.inspector.createParameters('Settings');
    gui.add(adjustments, 'mix', - 1, 2, 0.01);
    gui.add({ blurBackground: blurNode.value }, 'blurBackground', 0, 1, 0.01).onChange(value => {
      blurNode.value = value;
    });
    gui.add({ offsetHDR1: 0 }, 'offsetHDR1', 0, Math.PI * 2, 0.01).onChange(value => {
      rotateY1Matrix.makeRotationY(value);
    });
    gui.add({ offsetHDR2: 0 }, 'offsetHDR2', 0, Math.PI * 2, 0.01).onChange(value => {
      rotateY2Matrix.makeRotationY(value);
    });
    gui.add(adjustments, 'procedural', 0, 1, 0.01);
    gui.add(adjustments, 'intensity', 0, 5, 0.01);
    gui.add(adjustments, 'hue', 0, Math.PI * 2, 0.01);
    gui.add(adjustments, 'saturation', 0, 2, 0.01);
  }

  /**
   * 组件卸载时调用：释放资源、取消订阅、清理监听器（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例，字段含义同 onMount
   */
  onUnmount(core) {

  }

  /**
   * 每帧更新回调：处理实时逻辑（运动、动画、碰撞检测、AI 等），会持续触发
   * @param {VD.Core} core 引擎核心实例。core.timer.getDelta() 可获取上一帧到当前的间隔秒数，常用于基于时间增量的位移 / 旋转
   */
  onUpdate(core) {

  }
}