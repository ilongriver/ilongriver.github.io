const { time, mx_noise_vec3, instanceIndex, textureStore, float, vec3, vec4, If, Break, Fn, smoothstep, texture3D, uniform, RaymarchingBox } = TSL

class Script extends VD.Component {
  /**
   * 组件挂载时调用：初始化资源、订阅事件、设置初始状态（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例。常用字段：core.timer（计时器）、core.render.scene（三维场景）、core.render.camera（当前相机）、core.container（DOM 容器）
   */
  onMount(core) {
    // Sky

    const canvas = document.createElement('canvas');
    canvas.width = 1;
    canvas.height = 32;

    const context = canvas.getContext('2d');
    const gradient = context.createLinearGradient(0, 0, 0, 32);
    gradient.addColorStop(0.0, '#014a84');
    gradient.addColorStop(0.5, '#0561a0');
    gradient.addColorStop(1.0, '#437ab6');
    context.fillStyle = gradient;
    context.fillRect(0, 0, 1, 32);

    const skyMap = new THREE.CanvasTexture(canvas);
    skyMap.colorSpace = THREE.SRGBColorSpace;

    const sky = new THREE.Mesh(
      new THREE.SphereGeometry(10),
      new THREE.MeshBasicNodeMaterial({ map: skyMap, side: THREE.BackSide })
    );
    core.render.scene.add(sky);

    // Texture

    const size = 200;

    const computeCloud = Fn(({ storageTexture }) => {

      const scale = float(0.05);
      const id = instanceIndex;

      const x = id.mod(size);
      const y = id.div(size).mod(size);
      const z = id.div(size * size);


      const coord3d = vec3(x, y, z);
      const centered = coord3d.sub(size / 2).div(size);
      const d = float(1.0).sub(centered.length());

      const noiseCoord = coord3d.mul(scale.div(1.5)).add(time);

      const noise = mx_noise_vec3(noiseCoord).toConst('noise');

      const data = noise.mul(d).mul(d).toConst('data');

      textureStore(storageTexture, vec3(x, y, z), vec4(vec3(data.x), 1.0));

    });

    const storageTexture = new THREE.Storage3DTexture(size, size, size);
    storageTexture.generateMipmaps = false;
    storageTexture.name = 'cloud';

    this.computeNode = computeCloud({ storageTexture }).compute(size * size * size).setName('computeCloud');

    // Shader

    const transparentRaymarchingTexture = Fn(({
      texture,
      range = float(0.14),
      threshold = float(0.08),
      opacity = float(0.18),
      steps = float(100)
    }) => {

      const finalColor = vec4(0).toVar();

      RaymarchingBox(steps, ({ positionRay }) => {

        const mapValue = float(texture.sample(positionRay.add(0.5)).r).toVar();

        mapValue.assign(smoothstep(threshold.sub(range), threshold.add(range), mapValue).mul(opacity));

        const shading = texture.sample(positionRay.add(vec3(- 0.01))).r.sub(texture.sample(positionRay.add(vec3(0.01))).r);

        const col = shading.mul(4.0).add(positionRay.x.add(positionRay.y).mul(0.5)).add(0.3);

        finalColor.rgb.addAssign(finalColor.a.oneMinus().mul(mapValue).mul(col));

        finalColor.a.addAssign(finalColor.a.oneMinus().mul(mapValue));

        If(finalColor.a.greaterThanEqual(0.95), () => {

          Break();

        });

      });

      return finalColor;

    });

    // Material

    const baseColor = uniform(new THREE.Color(0x798aa0));
    const range = uniform(0.1);
    const threshold = uniform(0.08);
    const opacity = uniform(0.08);
    const steps = uniform(100);

    const cloud3d = transparentRaymarchingTexture({
      texture: texture3D(storageTexture, null, 0),
      range,
      threshold,
      opacity,
      steps
    });

    const finalCloud = cloud3d.setRGB(cloud3d.rgb.add(baseColor));

    const material = new THREE.NodeMaterial();
    material.colorNode = finalCloud;
    material.side = THREE.BackSide;
    material.transparent = true;
    material.name = 'transparentRaymarchingMaterial';

    this.mesh = new THREE.Mesh(new THREE.BoxGeometry(10, 10, 10), material);
    core.render.scene.add(this.mesh);

    this.mesh.rotation.y = Math.PI / 2;

    core.render.renderer.compute(this.computeNode);

    const gui = core.render.renderer.inspector.createParameters('Settings');
    gui.add(threshold, 'value', 0, 1, 0.01).name('threshold');
    gui.add(opacity, 'value', 0, 1, 0.01).name('opacity');
    gui.add(range, 'value', 0, 1, 0.01).name('range');
    gui.add(steps, 'value', 0, 200, 1).name('steps');
  }

  /**
   * 组件卸载时调用：释放资源、取消订阅、清理监听器（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例，字段含义同 onMount
   */
  onUnmount(core) {

  }

  /**
   * 每帧更新回调：处理实时逻辑（运动、动画、碰撞检测、AI 等），会持续触发
   * @param {VD.Core} core 引擎核心实例。core.timer.getDelta() 可获取上一帧到当前的间隔秒数，常用于基于时间增量的位移 / 旋转
   */
  onUpdate(core) {
    core.render.renderer.compute(this.computeNode);
  }
}