class FlakesTexture {

  /**
   * Generates a new flakes texture image. The result is a canvas
   * that can be used as an input for {@link CanvasTexture}.
   *
   * @param {number} [width=512] - The width of the image.
   * @param {number} [height=512] - The height of the image.
   * @return {HTMLCanvasElement} The generated image.
   */
  constructor(width = 512, height = 512) {

    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;

    const context = canvas.getContext('2d');
    context.fillStyle = 'rgb(127,127,255)';
    context.fillRect(0, 0, width, height);

    for (let i = 0; i < 4000; i++) {

      const x = Math.random() * width;
      const y = Math.random() * height;
      const r = Math.random() * 3 + 3;

      let nx = Math.random() * 2 - 1;
      let ny = Math.random() * 2 - 1;
      let nz = 1.5;

      const l = Math.sqrt(nx * nx + ny * ny + nz * nz);

      nx /= l; ny /= l; nz /= l;

      context.fillStyle = 'rgb(' + (nx * 127 + 127) + ',' + (ny * 127 + 127) + ',' + (nz * 255) + ')';
      context.beginPath();
      context.arc(x, y, r, 0, Math.PI * 2);
      context.fill();

    }

    return canvas;

  }

}

class Script extends VD.Component {
  /**
   * @field
   * @type {THREE.Material}
   * @label carPaint
   */
  carPaint = null;

  /** 
   * @param {VD.Core} core
   */
  onMount(core) {
    const normalMap3 = new THREE.CanvasTexture(new FlakesTexture());
    normalMap3.wrapS = THREE.RepeatWrapping;
    normalMap3.wrapT = THREE.RepeatWrapping;
    normalMap3.repeat.x = 10;
    normalMap3.repeat.y = 6;
    normalMap3.anisotropy = 16;

    this.carPaint.normalMap = normalMap3
    this.carPaint.needsUpdate = true

    this.particleLight = new THREE.Mesh(
      new THREE.SphereGeometry(.05, 8, 8),
      new THREE.MeshBasicMaterial({ color: 0xffffff })
    );
    this.particleLight.add(new THREE.PointLight(0xffffff, 30));

    core.render.scene.add(this.particleLight);
  }

  /**
   * @param {VD.Core} core
   */
  onUnmount(core) {

  }

  /**
   * @param {VD.Core} core
   */
  onRenderBefore(core) {
    const timer = Date.now() * 0.00025;

    this.particleLight.position.x = Math.sin(timer * 7) * 3;
    this.particleLight.position.y = Math.cos(timer * 5) * 4;
    this.particleLight.position.z = Math.cos(timer * 3) * 3;

    for (let i = 0; i < this.object.children.length; i++) {

      const child = this.object.children[i];
      child.rotation.y += 0.005;

    }
  }
}