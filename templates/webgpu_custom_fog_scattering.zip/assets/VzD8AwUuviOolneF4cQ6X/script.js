const params = {
  scatteringEnabled: true
};

class Script extends VD.Component {
  /**
   * 组件挂载时调用：初始化资源、订阅事件、设置初始状态（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例。常用字段：core.timer（计时器）、core.render.scene（三维场景）、core.render.camera（当前相机）、core.container（DOM 容器）
   */
  onMount(core) {
    // everything is a flat black silhouette — the fog and the scattering blur
    // do all the shaping, so no lights are needed ( MeshBasicMaterial is unlit )

    const material = new THREE.MeshBasicMaterial({ color: 0x000000 });

    // a few seeded variants of a tall scots pine: a clean bole rising into a
    // high, open crown of fine bare branches

    const variants = [];

    const generator = new ADDONS.TreeGenerator(material);

    for (let v = 0; v < 6; v++) {

      const mesh = generator
        .setSeed(v + 1)
        .setTrunkLength(2.6 + v * 0.3) // the crowns ride high in the fog
        .setTrunkRadius(0.06)
        .setTaper(0.28) // slender, tapers slowly
        .setLevels(4)
        .setChildren([7, 5, 4]) // a wide whorl of limbs ramifying into many fine twigs
        .setBranchAngle([55, 50, 46]) // a rounded crown that turns up
        .setAngleVariance(22)
        .setLengthRatio(0.46) // short crown limbs ( a modest pine crown )
        .setMinLength(0.04)
        .setDroop(0.05)
        .setUpPull(0.42) // crown branches reach up toward the light
        .setGnarl([0, 0.14, 0.24, 0.34]) // dead-straight trunk, wispier twigs
        .setSectionLength(0.34)
        .setRadialSegments(7)
        .setRadiusExponent(2.5) // slender bole, whippy thin twigs
        .setMinRadius(0.0023) // very fine twigs
        .setTrunkClear(0.72) // tall clean bole; the crown sits only at the top
        .build();

      variants.push(mesh.geometry);

    }

    const placements = variants.map(() => []);

    const dummy = new THREE.Object3D();
    const cols = 13, rows = 12, spacing = 1.9;

    for (let i = 0; i < cols; i++) {

      for (let j = 0; j < rows; j++) {

        const v = Math.floor(Math.random() * variants.length);

        const x = (i - cols / 2) * spacing + (Math.random() - 0.5) * spacing * 0.8;
        const z = j * spacing - rows * spacing + 4.2 + (Math.random() - 0.5) * spacing * 0.8;

        dummy.position.set(x, 0, z);

        const scale = 0.85 + Math.random() * 0.4;
        dummy.rotation.set((Math.random() - 0.5) * 0.05, Math.random() * Math.PI * 2, (Math.random() - 0.5) * 0.05); // slight lean
        dummy.scale.set(scale, scale * (0.9 + Math.random() * 0.3), scale);
        dummy.updateMatrix();

        placements[v].push(dummy.matrix.clone());

      }

    }

    variants.forEach((geometry, v) => {

      const list = placements[v];
      const mesh = new THREE.InstancedMesh(geometry, material, list.length);
      for (let k = 0; k < list.length; k++) mesh.setMatrixAt(k, list[k]);
      mesh.instanceMatrix.needsUpdate = true;
      core.render.scene.add(mesh);

    });

    // a couple of dominant trunks close to the camera to anchor the depth

    [[- 1.1, 4.9, 1.5, 1.1], [1.5, 4, 1.2, 0.3]].forEach(([x, z, s, ry]) => {

      const hero = new THREE.Mesh(variants[variants.length - 1], material);
      hero.position.set(x, 0, z);
      hero.rotation.y = ry;
      hero.scale.setScalar(s);
      core.render.scene.add(hero);

    });

    // ground

    const ground = new THREE.Mesh(new THREE.PlaneGeometry(600, 600).rotateX(- Math.PI / 2), material);
    core.render.scene.add(ground);

    // controls
    const controls = VD.getComponent(core.render.camera, '第一人称控制器')

    controls.controls.lookAt(- 0.2, 1.7, - 8)

    // uniforms
    const { reference, uniform, pass, gaussianBlur, vec2, densityFogFactor, mix } = TSL

    const density = reference('density', 'float', core.render.scene.fog);
    const scattering = uniform(2);

    // scene pass

    const scenePass = pass(core.render.scene, core.render.camera);

    const scenePassColor = scenePass.getTextureNode('output');
    const scenePassViewZ = scenePass.getViewZNode();

    // blur pass (always downsampled to improve performance)

    const sceneColorBlurred = gaussianBlur(scenePassColor, vec2(scattering), 4, { resolutionScale: 0.5 });

    // composite

    const fogFactor = densityFogFactor(density).context({ getViewZ: () => scenePassViewZ });

    const compositeNode = mix(scenePassColor, sceneColorBlurred, fogFactor);

    core.render.pipeline.outputNode = compositeNode;

    // gui

    const gui = core.render.renderer.inspector.createParameters('Settings');
    gui.add(core.render.scene.fog, 'density', 0.025, 0.16).step(0.0005).name('fog density');
    gui.add(scattering, 'value', 0, 5).name('scattering factor');
    gui.add(params, 'scatteringEnabled').name('enable scattering').onChange((value) => {

      if (value === true) {

        core.render.pipeline.outputNode = compositeNode;

      } else {

        core.render.pipeline.outputNode = scenePassColor;

      }

      core.render.pipeline.needsUpdate = true;

    });
  }

  /**
   * 组件卸载时调用：释放资源、取消订阅、清理监听器（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例，字段含义同 onMount
   */
  onUnmount(core) {

  }

  /**
   * 每帧更新回调：处理实时逻辑（运动、动画、碰撞检测、AI 等），会持续触发
   * @param {VD.Core} core 引擎核心实例。core.timer.getDelta() 可获取上一帧到当前的间隔秒数，常用于基于时间增量的位移 / 旋转
   */
  onUpdate(core) {

  }
}