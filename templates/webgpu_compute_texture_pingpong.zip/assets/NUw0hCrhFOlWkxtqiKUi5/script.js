const { storageTexture, textureStore, Fn, instanceIndex, uniform, float, vec2, vec4, uvec2, ivec2, int, NodeAccess } = TSL

let pingTexture, pongTexture;
let material;
let phase = true;
let lastUpdate = - 1;

const width = 512, height = 512;

const seed = uniform(new THREE.Vector2());

class Script extends VD.Component {
  /**
   * 组件挂载时调用：初始化资源、订阅事件、设置初始状态（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例。常用字段：core.timer（计时器）、core.render.scene（三维场景）、core.render.camera（当前相机）、core.container（DOM 容器）
   */
  onMount(core) {
    // texture

    const hdr = true;

    pingTexture = new THREE.StorageTexture(width, height);
    pongTexture = new THREE.StorageTexture(width, height);

    if (hdr) {

      pingTexture.type = THREE.HalfFloatType;
      pongTexture.type = THREE.HalfFloatType;

    }

    const rand2 = Fn(([n]) => {

      return n.dot(vec2(12.9898, 4.1414)).sin().mul(43758.5453).fract();

    });

    // Create storage texture nodes with proper access
    const writePing = storageTexture(pingTexture).setAccess(NodeAccess.WRITE_ONLY);
    const readPing = storageTexture(pingTexture).setAccess(NodeAccess.READ_ONLY);
    const writePong = storageTexture(pongTexture).setAccess(NodeAccess.WRITE_ONLY);
    const readPong = storageTexture(pongTexture).setAccess(NodeAccess.READ_ONLY);

    const computeInit = Fn(() => {

      const posX = instanceIndex.mod(width);
      const posY = instanceIndex.div(width);
      const indexUV = uvec2(posX, posY);
      const uv = vec2(float(posX).div(width), float(posY).div(height));

      const r = rand2(uv.add(seed.mul(100))).sub(rand2(uv.add(seed.mul(300))));
      const g = rand2(uv.add(seed.mul(200))).sub(rand2(uv.add(seed.mul(300))));
      const b = rand2(uv.add(seed.mul(200))).sub(rand2(uv.add(seed.mul(100))));

      textureStore(writePing, indexUV, vec4(r, g, b, 1));
    });

    this.computeInitNode = computeInit().compute(width * height);

    // compute ping-pong: blur function using .load() for textureLoad
    const blur = Fn(([readTex, uv]) => {

      const c0 = readTex.load(uv.add(ivec2(- 1, 1)));
      const c1 = readTex.load(uv.add(ivec2(- 1, - 1)));
      const c2 = readTex.load(uv.add(ivec2(0, 0)));
      const c3 = readTex.load(uv.add(ivec2(1, - 1)));
      const c4 = readTex.load(uv.add(ivec2(1, 1)));

      return c0.add(c1).add(c2).add(c3).add(c4).div(5.0);

    });

    // compute loop: read from one texture, blur, write to another
    const computePingPong = Fn(([readTex, writeTex]) => {

      const posX = instanceIndex.mod(width);
      const posY = instanceIndex.div(width);
      const indexUV = ivec2(int(posX), int(posY));

      const color = blur(readTex, indexUV);

      textureStore(writeTex, indexUV, vec4(color.rgb.mul(1.05), 1));

    });

    this.computeToPong = computePingPong(readPing, writePong).compute(width * height);
    this.computeToPing = computePingPong(readPong, writePing).compute(width * height);

    //

    this.material = new THREE.MeshBasicMaterial({ color: 0xffffff, map: pongTexture });

    const plane = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), this.material);
    core.render.scene.add(plane);

    core.render.renderer.compute(this.computeInitNode);

    this.onResize()
  }

  /**
   * 组件卸载时调用：释放资源、取消订阅、清理监听器（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例，字段含义同 onMount
   */
  onUnmount(core) {

  }

  /**
   * 每帧更新回调：处理实时逻辑（运动、动画、碰撞检测、AI 等），会持续触发
   * @param {VD.Core} core 引擎核心实例。core.timer.getDelta() 可获取上一帧到当前的间隔秒数，常用于基于时间增量的位移 / 旋转
   */
  onUpdate(core) {
    const time = performance.now();
    const seconds = Math.floor(time / 1000);

    // reset every second

    if (phase && seconds !== lastUpdate) {

      seed.value.set(Math.random(), Math.random());

      core.render.renderer.compute(this.computeInitNode);

      lastUpdate = seconds;

    }

    // compute step

    core.render.renderer.compute(phase ? this.computeToPong : this.computeToPing);

    this.material.map = phase ? pongTexture : pingTexture;

    phase = !phase;
  }

  onResize() {
    const aspect = window.innerWidth / window.innerHeight;

    const frustumHeight = this.object.top - this.object.bottom;

    this.object.left = - frustumHeight * aspect / 2;
    this.object.right = frustumHeight * aspect / 2;

    this.object.updateProjectionMatrix();
  }
}