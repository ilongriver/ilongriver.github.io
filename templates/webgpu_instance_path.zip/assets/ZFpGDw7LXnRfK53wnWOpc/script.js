
const count = 1000;

class Script extends VD.Component {
  /**
   * 组件挂载时调用：初始化资源、订阅事件、设置初始状态（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例。常用字段：core.timer（计时器）、core.render.scene（三维场景）、core.render.camera（当前相机）、core.container（DOM 容器）
   */
  onMount(core) {
    const { screenUV, color, instancedBufferAttribute, time, mod, sin, abs, select, float, vec3, add, positionLocal } = TSL

    core.render.scene.backgroundNode = screenUV.distance(.5).remap(0, 0.65).mix(color(0x94254c), color(0x000000));

    // generate a path representing a heart shape

    const x = 0, y = 0;

    const path = new THREE.Path()
      .moveTo(x - 2.5, y - 2.5)
      .bezierCurveTo(x - 2.5, y - 2.5, x - 2, y, x, y)
      .bezierCurveTo(x + 3, y, x + 3, y - 3.5, x + 3, y - 3.5)
      .bezierCurveTo(x + 3, y - 5.5, x + 1, y - 7.7, x - 2.5, y - 9.5)
      .bezierCurveTo(x - 6, y - 7.7, x - 8, y - 5.5, x - 8, y - 3.5)
      .bezierCurveTo(x - 8, y - 3.5, x - 8, y, x - 5, y)
      .bezierCurveTo(x - 3.5, y, x - 2.5, y - 2.5, x - 2.5, y - 2.5);

    // generate instanced ico-spheres along the path

    const geometry = new THREE.IcosahedronGeometry(0.1);
    const material = new THREE.MeshStandardNodeMaterial();

    const mesh = new THREE.Mesh(geometry, material);
    mesh.position.set(2.5, 5, 0);
    mesh.count = count;
    mesh.frustumCulled = false;

    core.render.scene.add(mesh);

    // instance data

    const v = new THREE.Vector3();
    const c = new THREE.Color();

    const positions = [];
    const times = [];
    const seeds = [];
    const colors = [];

    for (let i = 0; i < count; i++) {

      const t = i / count;
      path.getPointAt(t, v);

      v.x += (0.5 - Math.random());
      v.y += (0.5 - Math.random());
      v.z = (0.5 - Math.random());

      positions.push(v.x, v.y, v.z);
      times.push(t);
      seeds.push(Math.random());

      c.setHSL(0.75 + (Math.random() * 0.25), 1, 0.4);

      colors.push(c.r, c.g, c.b);

    }

    const positionAttribute = new THREE.InstancedBufferAttribute(new Float32Array(positions), 3);
    const colorAttribute = new THREE.InstancedBufferAttribute(new Float32Array(colors), 3);
    const timeAttribute = new THREE.InstancedBufferAttribute(new Float32Array(times), 1);
    const seedAttribute = new THREE.InstancedBufferAttribute(new Float32Array(seeds), 1);

    // TSL

    const instancePosition = instancedBufferAttribute(positionAttribute);
    const instanceColor = instancedBufferAttribute(colorAttribute);
    const instanceSeed = instancedBufferAttribute(seedAttribute);
    const instanceTime = instancedBufferAttribute(timeAttribute);

    const localTime = instanceTime.add(time);
    const modTime = mod(time.mul(0.4), 1);

    const s0 = sin(localTime.add(instanceSeed)).mul(0.25);

    const dist = abs(instanceTime.sub(modTime)).toConst(); // modTime and instanceTime are in the range [0,1]
    const wrapDist = select(dist.greaterThan(0.5), dist.oneMinus(), dist).toConst(); // the normalized distance should wrap around 0/1
    const s1 = select(wrapDist.greaterThan(0.1), float(1), wrapDist.remap(0, 0.1, 3, 1)); // compute a scale in a range around the current interpolated value

    const offset = vec3(instancePosition.x, instancePosition.y.add(s0), instancePosition.z).toConst('offset');
    material.positionNode = add(positionLocal.mul(s1), offset);
    material.colorNode = instanceColor;

    const pmremGenerator = new THREE.PMREMGenerator(core.render.renderer);
    core.render.scene.environment = pmremGenerator.fromScene(new ADDONS.RoomEnvironment(), 0.04).texture;

  }

  /**
   * 组件卸载时调用：释放资源、取消订阅、清理监听器（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例，字段含义同 onMount
   */
  onUnmount(core) {

  }

  /**
   * 每帧更新回调：处理实时逻辑（运动、动画、碰撞检测、AI 等），会持续触发
   * @param {VD.Core} core 引擎核心实例。core.timer.getDelta() 可获取上一帧到当前的间隔秒数，常用于基于时间增量的位移 / 旋转
   */
  onUpdate(core) {

  }
}