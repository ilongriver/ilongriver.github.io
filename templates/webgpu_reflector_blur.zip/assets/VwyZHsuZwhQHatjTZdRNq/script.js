class Script extends VD.Component {
  /** 
   * @param {VD.Core} core
   */
  onMount(core) {
    const { reflector, gaussianBlur, uniform } = TSL;

    const uRadius = uniform(1.2)
    const uScale = uniform(0.2)

    const reflection = reflector({ resolutionScale: 1 });
    reflection.target.rotateX(-Math.PI / 2);
    core.render.scene.add(reflection.target);

    // gaussianBlur(纹理节点, 模糊半径)
    const blurredReflection = gaussianBlur(reflection, uRadius);

    const floorMaterial = new THREE.MeshBasicNodeMaterial();
    floorMaterial.colorNode = blurredReflection.mul(uScale);

    const floor = new THREE.Mesh(
      new THREE.BoxGeometry(30, 0.001, 100),
      floorMaterial
    );
    core.render.scene.add(floor);

    const gui = core.render.renderer.inspector.createParameters("settings")
    gui.add(uRadius, 'value').name('radius')
    gui.add(uScale, 'value').name('scale')
  }

  /**
   * @param {VD.Core} core
   */
  onUnmount(core) {

  }

  /**
   * @param {VD.Core} core
   */
  onUpdate(core) {

  }
}