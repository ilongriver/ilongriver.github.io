class Script extends VD.Component {
  /**
   * @field
   * @type {THREE.Object3D} 
   * @label sourceModel
   */
  sourceModel = null;

  /**
   * @field
   * @type {THREE.Object3D} 
   * @label targetModel
   */
  targetModel = null;

  /** 
   * @param {VD.Core} core
   */
  onMount(core) {
    this.helpers = new THREE.Group();
    this.helpers.visible = false;
    core.render.scene.add(this.helpers);

    this.targetModel.scale.setScalar(0.01)

    this.source = this.getSource(this.sourceModel);
    this.mixer = this.retargetModel(this.source, this.targetModel);

    const gui = core.render.renderer.inspector.createParameters('Scene settings');
    gui.add(this.helpers, 'visible').name('show helpers');
  }

  /**
   * @param {VD.Core} core
   */
  onUnmount(core) {

  }

  /**
   * @param {VD.Core} core
   */
  onRenderBefore(core) {
    const delta = core.timer.getDelta()

    this.source.mixer.update(delta);
    this.mixer.update(delta);
  }

  getSource(sourceModel) {
    const clip = sourceModel.animations[0];

    const helper = new THREE.SkeletonHelper(sourceModel);
    this.helpers.add(helper);

    const skeleton = new THREE.Skeleton(helper.bones);

    const mixer = new THREE.AnimationMixer(sourceModel);
    mixer.clipAction(sourceModel.animations[0]).play();

    return { clip, skeleton, mixer };

  }

  retargetModel(sourceModel, targetModel) {

    const targetSkin = targetModel.children[0].children[0];

    const targetSkelHelper = new THREE.SkeletonHelper(targetModel);
    this.helpers.add(targetSkelHelper);

    const rotateCW45 = new THREE.Matrix4().makeRotationY(THREE.MathUtils.degToRad(45));
    const rotateCCW180 = new THREE.Matrix4().makeRotationY(THREE.MathUtils.degToRad(- 180));
    const rotateCW180 = new THREE.Matrix4().makeRotationY(THREE.MathUtils.degToRad(180));
    const rotateFoot = new THREE.Matrix4().makeRotationFromEuler(new THREE.Euler(THREE.MathUtils.degToRad(45), THREE.MathUtils.degToRad(180), THREE.MathUtils.degToRad(0)));

    const retargetOptions = {

      // specify the name of the source's hip bone.
      hip: 'mixamorigHips',

      // specify the influence of the source's hip bone.
      // use ( 0, 1, 0 ) to ignore xz hip movement.
      //hipInfluence: new THREE.Vector3( 0, 1, 0 ),

      // specify an animation range in seconds.
      //trim: [ 3.0, 4.0 ],

      // preserve the scale of the target model
      scale: 1 / targetModel.scale.y,

      // offset target bones -> { targetBoneName: offsetMatrix }
      localOffsets: {

        mixamorigLeftShoulder: rotateCW45,
        mixamorigRightShoulder: rotateCCW180,
        mixamorigLeftArm: rotateCW45,
        mixamorigRightArm: rotateCCW180,
        mixamorigLeftForeArm: rotateCW45,
        mixamorigRightForeArm: rotateCCW180,
        mixamorigLeftHand: rotateCW45,
        mixamorigRightHand: rotateCCW180,

        mixamorigLeftUpLeg: rotateCW180,
        mixamorigRightUpLeg: rotateCW180,
        mixamorigLeftLeg: rotateCW180,
        mixamorigRightLeg: rotateCW180,
        mixamorigLeftFoot: rotateFoot,
        mixamorigRightFoot: rotateFoot,
        mixamorigLeftToeBase: rotateCW180,
        mixamorigRightToeBase: rotateCW180

      },

      // Map of target's bone names to source's bone names -> { targetBoneName: sourceBoneName }
      names: {

        mixamorigHips: 'mixamorigHips',

        mixamorigSpine: 'mixamorigSpine',
        mixamorigSpine2: 'mixamorigSpine2',
        mixamorigHead: 'mixamorigHead',

        mixamorigLeftShoulder: 'mixamorigLeftShoulder',
        mixamorigRightShoulder: 'mixamorigRightShoulder',
        mixamorigLeftArm: 'mixamorigLeftArm',
        mixamorigRightArm: 'mixamorigRightArm',
        mixamorigLeftForeArm: 'mixamorigLeftForeArm',
        mixamorigRightForeArm: 'mixamorigRightForeArm',
        mixamorigLeftHand: 'mixamorigLeftHand',
        mixamorigRightHand: 'mixamorigRightHand',

        mixamorigLeftUpLeg: 'mixamorigLeftUpLeg',
        mixamorigRightUpLeg: 'mixamorigRightUpLeg',
        mixamorigLeftLeg: 'mixamorigLeftLeg',
        mixamorigRightLeg: 'mixamorigRightLeg',
        mixamorigLeftFoot: 'mixamorigLeftFoot',
        mixamorigRightFoot: 'mixamorigRightFoot',
        mixamorigLeftToeBase: 'mixamorigLeftToeBase',
        mixamorigRightToeBase: 'mixamorigRightToeBase'

      }

    };

    const retargetedClip = ADDONS.SkeletonUtils.retargetClip(targetSkin, sourceModel.skeleton, sourceModel.clip, retargetOptions);

    // Apply the mixer directly to the SkinnedMesh, not any
    // ancestor node, because that's what
    // SkeletonUtils.retargetClip outputs the clip to be
    // compatible with.
    const mixer = new THREE.AnimationMixer(targetSkin);
    mixer.clipAction(retargetedClip).play();

    return mixer;
  }
}


