const offset = 5000;

const timeOffsets = new Float32Array(1024);

for (let i = 0; i < 1024; i++) {

  timeOffsets[i] = Math.random() * 3;

}

class Script extends VD.Component {
  /**
   * @field
   * @type {THREE.Object3D}
   */
  horse
  /**
   * 组件挂载时调用：初始化资源、订阅事件、设置初始状态（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例。常用字段：core.timer（计时器）、core.render.scene（三维场景）、core.render.camera（当前相机）、core.container（DOM 容器）
   */
  onMount(core) {
    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(1000000, 1000000),
      new THREE.MeshStandardMaterial({ color: 0x669933 })
    );

    ground.rotation.x = - Math.PI / 2;

    ground.receiveShadow = true;

    core.render.scene.add(ground);

    this.dummy = this.horse.children[0]

    this.mesh = new THREE.InstancedMesh(this.dummy.geometry, new THREE.MeshStandardNodeMaterial({
      flatShading: true,
    }), 1024);

    this.mesh.castShadow = true;

    for (let x = 0, i = 0; x < 32; x++) {
      for (let y = 0; y < 32; y++) {

        this.dummy.position.set(offset - 300 * x + 200 * Math.random(), 0, offset - 300 * y);

        this.dummy.updateMatrix();

        this.mesh.setMatrixAt(i, this.dummy.matrix);

        this.mesh.setColorAt(i, new THREE.Color(`hsl(${Math.random() * 360}, 50%, 66%)`));

        i++;

      }
    }


    core.render.scene.add(this.mesh);

    this.mixer = new THREE.AnimationMixer(this.horse);

    const action = this.mixer.clipAction(this.horse.animations[0]);

    action.play();

    this.horse.visible = false
  }

  /**
   * 组件卸载时调用：释放资源、取消订阅、清理监听器（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例，字段含义同 onMount
   */
  onUnmount(core) {

  }

  /**
   * 每帧更新回调：处理实时逻辑（运动、动画、碰撞检测、AI 等），会持续触发
   * @param {VD.Core} core 引擎核心实例。core.timer.getDelta() 可获取上一帧到当前的间隔秒数，常用于基于时间增量的位移 / 旋转
   */
  onUpdate(core) {
    const time = core.timer.getElapsed();

    const r = 3000;
    core.render.camera.position.set(Math.sin(time / 10) * r, 1500 + 1000 * Math.cos(time / 5), Math.cos(time / 10) * r);
    core.render.camera.lookAt(0, 0, 0);

    for (let i = 0; i < 1024; i++) {

      this.mixer.setTime(time + timeOffsets[i]);

      this.mesh.setMorphAt(i, this.dummy);

    }

    this.mesh.morphTexture.needsUpdate = true;

  }
}