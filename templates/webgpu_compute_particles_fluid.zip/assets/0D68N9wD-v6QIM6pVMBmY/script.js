const { Fn, If, Return, instancedArray, instanceIndex, uniform, attribute, float, clamp, struct, atomicStore, int,
  ivec3, array, vec3, atomicAdd, Loop, atomicLoad, max, pow, mat3, vec4, cross, step, storage } = TSL;

const maxParticles = 8192 * 16;
const gridSize1d = 64;
const workgroupSize = 64;
const gridSize = new THREE.Vector3(gridSize1d, gridSize1d, gridSize1d);
const fixedPointMultiplier = 1e7;

const params = {
  particleCount: 8192 * 4,
};

const mouseCoord = new THREE.Vector3();
const prevMouseCoord = new THREE.Vector3();

class Script extends VD.Component {
  /** 
   * @param {VD.Core} core
   */
  onMount(core) {
    this.setupParticles()

    const numWorkgroups = Math.ceil(params.particleCount / workgroupSize);

    this.p2g1KernelWorkgroupBuffer = new THREE.IndirectStorageBufferAttribute(new Uint32Array([numWorkgroups, 1, 1]), 1);
    this.p2g2KernelWorkgroupBuffer = new THREE.IndirectStorageBufferAttribute(new Uint32Array([numWorkgroups, 1, 1]), 1);
    this.g2pKernelWorkgroupBuffer = new THREE.IndirectStorageBufferAttribute(new Uint32Array([numWorkgroups, 1, 1]), 1);

    const p2g1WorkgroupStorage = storage(this.p2g1KernelWorkgroupBuffer, 'uint', 3);
    const p2g2WorkgroupStorage = storage(this.p2g2KernelWorkgroupBuffer, 'uint', 3);
    const g2pWorkgroupStorage = storage(this.g2pKernelWorkgroupBuffer, 'uint', 3);

    this.workgroupKernel = Fn(() => {
      const workgroupsToDispatch = (this.particleCountUniform.sub(1)).div(workgroupSize).add(1);

      p2g1WorkgroupStorage.element(0).assign(workgroupsToDispatch);
      p2g2WorkgroupStorage.element(0).assign(workgroupsToDispatch);
      g2pWorkgroupStorage.element(0).assign(workgroupsToDispatch);
    })().compute(1);

    const gui = core.render.renderer.inspector.createParameters('Settings');
    gui.add(params, 'particleCount', 4096, maxParticles, 4096).onChange(value => {
      this.particleMesh.count = value;
      this.p2g1Kernel.count = value;
      this.p2g2Kernel.count = value;
      this.g2pKernel.count = value;
      this.particleCountUniform.value = value;
    });
  }

  /**
   * @param {VD.Core} core
   */
  onUnmount(core) {

  }

  /**
   * @param {VD.Core} core
   */
  onUpdate(core) {
    const deltaTime = THREE.MathUtils.clamp(core.timer.getDelta(), 0.00001, 1 / 60); // don't advance the time too far, for example when the window is out of focus
    this.dtUniform.value = deltaTime;

    this.mouseForceUniform.value.copy(mouseCoord).sub(prevMouseCoord).multiplyScalar(2);
    const mouseForceLength = this.mouseForceUniform.value.length();
    if (mouseForceLength > 0.3) {
      this.mouseForceUniform.value.multiplyScalar(0.3 / mouseForceLength);
    }

    prevMouseCoord.copy(mouseCoord);

    core.render.renderer.compute(this.workgroupKernel);

    //renderer.compute( [ clearGridKernel, p2g1Kernel, p2g2Kernel, updateGridKernel, g2pKernel ] );
    core.render.renderer.compute(this.clearGridKernel);
    core.render.renderer.compute(this.p2g1Kernel, this.p2g1KernelWorkgroupBuffer);
    core.render.renderer.compute(this.p2g2Kernel, this.p2g2KernelWorkgroupBuffer);
    core.render.renderer.compute(this.updateGridKernel);
    core.render.renderer.compute(this.g2pKernel, this.g2pKernelWorkgroupBuffer);
  }

  setupParticles() {
    this.setupBuffers();
    this.setupUniforms();
    this.setupComputeShaders();
    this.setupMesh();
    this.setupMouse();
  }

  setupBuffers() {
    const particleStruct = struct({
      position: { type: 'vec3' },
      velocity: { type: 'vec3' },
      C: { type: 'mat3' },
    });
    const particleStructSize = 20; // each vec3 occupies 4 floats and mat3 occupies 12 floats in memory because of webgpu memory alignment
    const particleArray = new Float32Array(maxParticles * particleStructSize);

    for (let i = 0; i < maxParticles; i++) {
      particleArray[i * particleStructSize] = (Math.random() * 0.8 + 0.1);
      particleArray[i * particleStructSize + 1] = (Math.random() * 0.8 + 0.1);
      particleArray[i * particleStructSize + 2] = (Math.random() * 0.8 + 0.1);

      // particleArray[i * particleStructSize] = Math.random();
      // particleArray[i * particleStructSize + 1] = Math.random();
      // particleArray[i * particleStructSize + 2] = Math.random();
    }

    this.particleBuffer = instancedArray(particleArray, particleStruct);

    const cellCount = gridSize.x * gridSize.y * gridSize.z;

    const cellStruct = struct({
      x: { type: 'int', atomic: true },
      y: { type: 'int', atomic: true },
      z: { type: 'int', atomic: true },
      mass: { type: 'int', atomic: true },
    });

    this.cellBuffer = instancedArray(cellCount, cellStruct);
    this.cellBufferFloat = instancedArray(cellCount, 'vec4');
  }

  setupUniforms() {
    this.gridSizeUniform = uniform(gridSize);
    this.particleCountUniform = uniform(params.particleCount, 'uint');
    this.stiffnessUniform = uniform(50);
    this.restDensityUniform = uniform(1.5);
    this.dynamicViscosityUniform = uniform(0.1);
    this.dtUniform = uniform(1 / 60);
    this.gravityUniform = uniform(new THREE.Vector3(0, - (9.81 * 9.81), 0));
    this.mouseRayOriginUniform = uniform(new THREE.Vector3(0, 0, 0));
    this.mouseRayDirectionUniform = uniform(new THREE.Vector3(0, 0, 0));
    this.mouseForceUniform = uniform(new THREE.Vector3(0, 0, 0));

    // gui.add(restDensityUniform, "value", 1.0, 3, 0.1).name("restDensity");
    // it's interesting to adjust the restDensity but it might cause the simulation to become unstable
  }

  setupComputeShaders() {

    // the MLS-MPM system uses five compute shaders:
    // 1. clearGridKernel: this clears the grid before each pass
    // 2. p2g1Kernel & 3. p2g2Kernel: These particle2grid kernels transfer the particles' energy to the grid
    // 4. updateGridKernel: updates the grid
    // 5. g2pKernel: grid2particle kernel, transfers the grid energy back to the particles
    // the implementation closely follows https://github.com/matsuoka-601/WebGPU-Ocean

    // because webgpu only supports int atomics, we use fixed point floats by multiplying/dividing the float values with a high integer constant
    const encodeFixedPoint = (f32) => {

      return int(f32.mul(fixedPointMultiplier));

    };

    const decodeFixedPoint = (i32) => {

      return float(i32).div(fixedPointMultiplier);

    };

    const cellCount = gridSize.x * gridSize.y * gridSize.z;
    this.clearGridKernel = Fn(() => {

      atomicStore(this.cellBuffer.element(instanceIndex).get('x'), 0);
      atomicStore(this.cellBuffer.element(instanceIndex).get('y'), 0);
      atomicStore(this.cellBuffer.element(instanceIndex).get('z'), 0);
      atomicStore(this.cellBuffer.element(instanceIndex).get('mass'), 0);

    })().compute(cellCount).setName('clearGridKernel');

    this.p2g1Kernel = Fn(() => {

      const particlePosition = this.particleBuffer.element(instanceIndex).get('position').toConst('particlePosition');
      const particleVelocity = this.particleBuffer.element(instanceIndex).get('velocity').toConst('particleVelocity');
      const C = this.particleBuffer.element(instanceIndex).get('C').toConst('C');

      const gridPosition = particlePosition.mul(this.gridSizeUniform).toVar();
      const cellIndex = ivec3(gridPosition).sub(1).toConst('cellIndex');
      const cellDiff = gridPosition.fract().sub(0.5).toConst('cellDiff');
      const w0 = float(0.5).mul(float(0.5).sub(cellDiff)).mul(float(0.5).sub(cellDiff));
      const w1 = float(0.75).sub(cellDiff.mul(cellDiff));
      const w2 = float(0.5).mul(float(0.5).add(cellDiff)).mul(float(0.5).add(cellDiff));
      const weights = array([w0, w1, w2]).toConst('weights');

      Loop({ start: 0, end: 3, type: 'int', name: 'gx', condition: '<' }, ({ gx }) => {

        Loop({ start: 0, end: 3, type: 'int', name: 'gy', condition: '<' }, ({ gy }) => {

          Loop({ start: 0, end: 3, type: 'int', name: 'gz', condition: '<' }, ({ gz }) => {

            const weight = weights.element(gx).x.mul(weights.element(gy).y).mul(weights.element(gz).z);
            const cellX = cellIndex.add(ivec3(gx, gy, gz)).toConst();
            const cellDist = vec3(cellX).add(0.5).sub(gridPosition).toConst('cellDist');
            const Q = C.mul(cellDist);

            const massContrib = weight; // assuming particle mass = 1.0
            const velContrib = massContrib.mul(particleVelocity.add(Q)).toConst('velContrib');
            const cellPtr = cellX.x.mul(int(gridSize.y * gridSize.z)).add(cellX.y.mul(int(gridSize.z))).add(cellX.z).toConst();
            const cell = this.cellBuffer.element(cellPtr);

            atomicAdd(cell.get('x'), encodeFixedPoint(velContrib.x));
            atomicAdd(cell.get('y'), encodeFixedPoint(velContrib.y));
            atomicAdd(cell.get('z'), encodeFixedPoint(velContrib.z));
            atomicAdd(cell.get('mass'), encodeFixedPoint(massContrib));

          });

        });

      });

    })().compute(params.particleCount, [workgroupSize, 1, 1]).setName('p2g1Kernel');

    this.p2g2Kernel = Fn(() => {

      const particlePosition = this.particleBuffer.element(instanceIndex).get('position').toConst('particlePosition');
      const gridPosition = particlePosition.mul(this.gridSizeUniform).toVar();

      const cellIndex = ivec3(gridPosition).sub(1).toConst('cellIndex');
      const cellDiff = gridPosition.fract().sub(0.5).toConst('cellDiff');
      const w0 = float(0.5).mul(float(0.5).sub(cellDiff)).mul(float(0.5).sub(cellDiff));
      const w1 = float(0.75).sub(cellDiff.mul(cellDiff));
      const w2 = float(0.5).mul(float(0.5).add(cellDiff)).mul(float(0.5).add(cellDiff));
      const weights = array([w0, w1, w2]).toConst('weights');

      const density = float(0).toVar('density');
      Loop({ start: 0, end: 3, type: 'int', name: 'gx', condition: '<' }, ({ gx }) => {

        Loop({ start: 0, end: 3, type: 'int', name: 'gy', condition: '<' }, ({ gy }) => {

          Loop({ start: 0, end: 3, type: 'int', name: 'gz', condition: '<' }, ({ gz }) => {

            const weight = weights.element(gx).x.mul(weights.element(gy).y).mul(weights.element(gz).z);
            const cellX = cellIndex.add(ivec3(gx, gy, gz)).toConst();
            const cellPtr = cellX.x.mul(int(gridSize.y * gridSize.z)).add(cellX.y.mul(int(gridSize.z))).add(cellX.z).toConst();
            const cell = this.cellBuffer.element(cellPtr);
            const mass = decodeFixedPoint(atomicLoad(cell.get('mass')));
            density.addAssign(mass.mul(weight));

          });

        });

      });

      const volume = float(1).div(density);
      const pressure = max(0.0, pow(density.div(this.restDensityUniform), 5.0).sub(1).mul(this.stiffnessUniform)).toConst('pressure');
      const stress = mat3(pressure.negate(), 0, 0, 0, pressure.negate(), 0, 0, 0, pressure.negate()).toVar('stress');
      const dudv = this.particleBuffer.element(instanceIndex).get('C').toConst('C');

      const strain = dudv.add(dudv.transpose());
      stress.addAssign(strain.mul(this.dynamicViscosityUniform));
      const eq16Term0 = volume.mul(- 4).mul(stress).mul(this.dtUniform);

      Loop({ start: 0, end: 3, type: 'int', name: 'gx', condition: '<' }, ({ gx }) => {

        Loop({ start: 0, end: 3, type: 'int', name: 'gy', condition: '<' }, ({ gy }) => {

          Loop({ start: 0, end: 3, type: 'int', name: 'gz', condition: '<' }, ({ gz }) => {

            const weight = weights.element(gx).x.mul(weights.element(gy).y).mul(weights.element(gz).z);
            const cellX = cellIndex.add(ivec3(gx, gy, gz)).toConst();
            const cellDist = vec3(cellX).add(0.5).sub(gridPosition).toConst('cellDist');
            const momentum = eq16Term0.mul(weight).mul(cellDist).toConst('momentum');

            const cellPtr = cellX.x.mul(int(gridSize.y * gridSize.z)).add(cellX.y.mul(int(gridSize.z))).add(cellX.z).toConst();
            const cell = this.cellBuffer.element(cellPtr);
            atomicAdd(cell.get('x'), encodeFixedPoint(momentum.x));
            atomicAdd(cell.get('y'), encodeFixedPoint(momentum.y));
            atomicAdd(cell.get('z'), encodeFixedPoint(momentum.z));

          });

        });

      });

    })().compute(params.particleCount, [workgroupSize, 1, 1]).setName('p2g2Kernel');

    this.updateGridKernel = Fn(() => {

      const cell = this.cellBuffer.element(instanceIndex);
      const mass = decodeFixedPoint(atomicLoad(cell.get('mass'))).toConst();
      If(mass.lessThanEqual(0), () => {

        Return();

      });

      const vx = decodeFixedPoint(atomicLoad(cell.get('x'))).div(mass).toVar();
      const vy = decodeFixedPoint(atomicLoad(cell.get('y'))).div(mass).toVar();
      const vz = decodeFixedPoint(atomicLoad(cell.get('z'))).div(mass).toVar();

      const x = int(instanceIndex).div(int(gridSize.z * gridSize.y));
      const y = int(instanceIndex).div(int(gridSize.z)).mod(int(gridSize.y));
      const z = int(instanceIndex).mod(int(gridSize.z));
      If(x.lessThan(int(1)).or(x.greaterThan(int(gridSize.x).sub(int(2)))), () => {

        vx.assign(0);

      });
      If(y.lessThan(int(1)).or(y.greaterThan(int(gridSize.y).sub(int(2)))), () => {

        vy.assign(0);

      });
      If(z.lessThan(int(1)).or(z.greaterThan(int(gridSize.z).sub(int(2)))), () => {

        vz.assign(0);

      });

      this.cellBufferFloat.element(instanceIndex).assign(vec4(vx, vy, vz, mass));

    })().compute(cellCount).setName('updateGridKernel');


    const clampToRoundedBox = (pos, box, radius) => {

      const result = pos.sub(0.5).toVar();
      const pp = step(box, result.abs()).mul(result.add(box.negate().mul(result.sign())));
      const ppLen = pp.length().toVar();
      const dist = ppLen.sub(radius);
      If(dist.greaterThan(0.0), () => {

        result.subAssign(pp.normalize().mul(dist).mul(1.3));

      });
      result.addAssign(0.5);
      return result;

    };

    this.g2pKernel = Fn(() => {

      const particlePosition = this.particleBuffer.element(instanceIndex).get('position').toVar('particlePosition');
      const gridPosition = particlePosition.mul(this.gridSizeUniform).toVar();
      const particleVelocity = vec3(0).toVar();

      const cellIndex = ivec3(gridPosition).sub(1).toConst('cellIndex');
      const cellDiff = gridPosition.fract().sub(0.5).toConst('cellDiff');

      const w0 = float(0.5).mul(float(0.5).sub(cellDiff)).mul(float(0.5).sub(cellDiff));
      const w1 = float(0.75).sub(cellDiff.mul(cellDiff));
      const w2 = float(0.5).mul(float(0.5).add(cellDiff)).mul(float(0.5).add(cellDiff));
      const weights = array([w0, w1, w2]).toConst('weights');

      const B = mat3(0).toVar('B');
      Loop({ start: 0, end: 3, type: 'int', name: 'gx', condition: '<' }, ({ gx }) => {

        Loop({ start: 0, end: 3, type: 'int', name: 'gy', condition: '<' }, ({ gy }) => {

          Loop({ start: 0, end: 3, type: 'int', name: 'gz', condition: '<' }, ({ gz }) => {

            const weight = weights.element(gx).x.mul(weights.element(gy).y).mul(weights.element(gz).z);
            const cellX = cellIndex.add(ivec3(gx, gy, gz)).toConst();
            const cellDist = vec3(cellX).add(0.5).sub(gridPosition).toConst('cellDist');
            const cellPtr = cellX.x.mul(int(gridSize.y * gridSize.z)).add(cellX.y.mul(int(gridSize.z))).add(cellX.z).toConst();

            const weightedVelocity = this.cellBufferFloat.element(cellPtr).xyz.mul(weight).toConst('weightedVelocity');
            const term = mat3(
              weightedVelocity.mul(cellDist.x),
              weightedVelocity.mul(cellDist.y),
              weightedVelocity.mul(cellDist.z)
            );
            B.addAssign(term);
            particleVelocity.addAssign(weightedVelocity);

          });

        });

      });

      this.particleBuffer.element(instanceIndex).get('C').assign(B.mul(4));

      // gravity
      particleVelocity.addAssign(this.gravityUniform.mul(this.dtUniform));

      // scale from (gridSize.x, gridSize.y, gridSize.z) to (1, 1, 1)
      particleVelocity.divAssign(this.gridSizeUniform);

      // mouseInteraction
      const dist = cross(this.mouseRayDirectionUniform, particlePosition.sub(this.mouseRayOriginUniform)).length();
      const force = dist.mul(3.00).oneMinus().max(0.0).pow(2);
      particleVelocity.addAssign(this.mouseForceUniform.mul(force));

      // add velocity to position
      particlePosition.addAssign(particleVelocity.mul(this.dtUniform));

      // clamp position so outermost gridCells are not reached
      particlePosition.assign(clamp(particlePosition, vec3(1).div(this.gridSizeUniform), vec3(gridSize).sub(1).div(this.gridSizeUniform)));

      // add force for particles to stay within rounded box
      const innerBox = this.gridSizeUniform.mul(0.5).sub(9.0).div(this.gridSizeUniform).toVar();
      const innerRadius = float(6.0).div(this.gridSizeUniform.x);
      const posNext = particlePosition.add(particleVelocity.mul(this.dtUniform).mul(2.0)).toConst('posNext');
      const posNextClamped = clampToRoundedBox(posNext, innerBox, innerRadius);
      particleVelocity.addAssign(posNextClamped.sub(posNext));

      /*
      const wallStiffness = 1.0;
      const xN = particlePosition.add( particleVelocity.mul( dtUniform ).mul( 2.0 ) ).toConst( 'xN' );
      const wallMin = vec3( 3 ).div(gridSizeUniform).toConst( 'wallMin' );
      const wallMax = vec3( gridSize ).sub( 3 ).div(gridSizeUniform).toConst( 'wallMax' );
      particleVelocity.addAssign( wallMin.sub( xN ).max( 0.0 ).mul( wallStiffness ) );
      particleVelocity.addAssign( wallMax.sub( xN ).min( 0.0 ).mul( wallStiffness ) );
      */

      // scale from (1, 1, 1) back to (gridSize.x, gridSize.y, gridSize.z) to
      particleVelocity.mulAssign(this.gridSizeUniform);

      this.particleBuffer.element(instanceIndex).get('position').assign(particlePosition);
      this.particleBuffer.element(instanceIndex).get('velocity').assign(particleVelocity);

    })().compute(params.particleCount, [workgroupSize, 1, 1]).setName('g2pKernel');
  }

  setupMesh() {

    // mergeVertices to reduce the number of vertexShaderCalls
    const geometry = ADDONS.BufferGeometryUtils.mergeVertices(new THREE.IcosahedronGeometry(0.008, 1).deleteAttribute('uv'));

    const material = new THREE.MeshStandardNodeMaterial({
      color: '#0066FF'
    });

    material.positionNode = Fn(() => {

      const particlePosition = this.particleBuffer.element(instanceIndex).get('position');
      return attribute('position').add(particlePosition);

    })();
    this.particleMesh = new THREE.Mesh(geometry, material);
    this.particleMesh.count = params.particleCount;
    this.particleMesh.position.set(- 0.5, 0, - 0.5);
    this.particleMesh.frustumCulled = false;
    this.core.render.scene.add(this.particleMesh);
  }

  setupMouse() {
    const raycaster = new THREE.Raycaster();
    const raycastPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0));

    const onMove = (event) => {

      const pointer = new THREE.Vector2((event.clientX / window.innerWidth) * 2 - 1, - (event.clientY / window.innerHeight) * 2 + 1);
      raycaster.setFromCamera(pointer, this.core.render.camera);
      raycaster.ray.origin.x += 0.5;
      raycaster.ray.origin.z += 0.5;
      this.mouseRayOriginUniform.value.copy(raycaster.ray.origin);
      this.mouseRayDirectionUniform.value.copy(raycaster.ray.direction);

      raycaster.ray.intersectPlane(raycastPlane, mouseCoord);
    };

    this.core.render.renderer.domElement.addEventListener('pointermove', onMove);
  }
}