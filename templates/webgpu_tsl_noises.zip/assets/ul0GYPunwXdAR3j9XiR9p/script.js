class Script extends VD.Component {
  /**
   * 组件挂载时调用：初始化资源、订阅事件、设置初始状态（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例。常用字段：core.timer（计时器）、core.render.scene（三维场景）、core.render.camera（当前相机）、core.container（DOM 容器）
   */
  onMount(core) {
    const { Fn, float, abs, uniform, Loop, vec2, floor, fract, mod, vec4, dot, step, vec3, max, uv } = TSL

    const uScale = uniform(5.0)
    const uLacunarity = uniform(2.0);
    const uGain = uniform(0.5);

    const permute3 = Fn(([x]) => {
      return mod(x.mul(34.0).add(1.0).mul(x), 289.0);
    });

    const simplexNoise = Fn(([v]) => {
      const C = vec4(
        0.211324865405187,
        0.366025403784439,
        -0.577350269189626,
        0.024390243902439,
      );

      const i = floor(v.add(dot(v, vec2(C.y, C.y))));
      const x0 = v.sub(i).add(dot(i, vec2(C.x, C.x)));

      const i1x = step(x0.y, x0.x);
      const i1y = float(1.0).sub(i1x);

      const x1 = x0.sub(vec2(i1x, i1y)).add(C.x);
      const x2 = x0.add(C.z);

      const ii = mod(i, 289.0);
      const p = permute3(
        permute3(vec3(ii.y, ii.y.add(i1y), ii.y.add(1.0))).add(
          vec3(ii.x, ii.x.add(i1x), ii.x.add(1.0)),
        ),
      );

      const m = max(
        float(0.5).sub(vec3(dot(x0, x0), dot(x1, x1), dot(x2, x2))),
        0.0,
      );
      const m2 = m.mul(m);
      const m4 = m2.mul(m2);

      const x_grad = fract(p.mul(C.w)).mul(2.0).sub(1.0);
      const h = abs(x_grad).sub(0.5);
      const ox = floor(x_grad.add(0.5));
      const a0 = x_grad.sub(ox);

      const m4_norm = m4.mul(
        float(1.79284291400159).sub(
          float(0.85373472095314).mul(a0.mul(a0).add(h.mul(h))),
        ),
      );

      const g = vec3(
        a0.x.mul(x0.x).add(h.x.mul(x0.y)),
        a0.y.mul(x1.x).add(h.y.mul(x1.y)),
        a0.z.mul(x2.x).add(h.z.mul(x2.y)),
      );

      const result = float(130.0).mul(dot(m4_norm, g));
      return result.mul(0.5).add(0.5);
    });

    const ridgedNoise = Fn(([p]) => {
      const value = float(0.0).toVar();
      const amplitude = float(0.5).toVar();
      const freq = float(1.0).toVar();
      const weight = float(1.0).toVar();
      const maxValue = float(0.0).toVar();

      Loop(3, () => {
        const n = simplexNoise(p.mul(freq)).sub(0.5).mul(2.0);
        const ridge = float(1.0).sub(abs(n));
        const signal = ridge.mul(ridge).mul(weight);
        value.addAssign(signal.mul(amplitude));
        maxValue.addAssign(amplitude);
        weight.assign(signal.clamp(0.0, 1.0));
        freq.mulAssign(uLacunarity);
        amplitude.mulAssign(uGain);
      });

      return value.div(maxValue).clamp(0.0, 1.0);
    });

    const material = new THREE.MeshBasicNodeMaterial()

    material.colorNode = Fn(() => {
      const p = uv().sub(0.5).mul(uScale);
      const result = ridgedNoise(p);
      return vec3(result.clamp(0.0, 1.0));
    })();
    material.side = THREE.DoubleSide;

    this.object.material = material

    const gui = core.render.renderer.inspector.createParameters('Ridged Noise');

    gui.add(uScale, 'value', 1, 50, 1).name('uScale')
    gui.add(uLacunarity, 'value', 1, 4, 0.1).name('uLacunarity')
    gui.add(uGain, 'value', 0.1, 0.9, 0.05).name('uGain')
  }

  /**
   * 组件卸载时调用：释放资源、取消订阅、清理监听器（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例，字段含义同 onMount
   */
  onUnmount(core) {

  }

  /**
   * 每帧更新回调：处理实时逻辑（运动、动画、碰撞检测、AI 等），会持续触发
   * @param {VD.Core} core 引擎核心实例。core.timer.getDelta() 可获取上一帧到当前的间隔秒数，常用于基于时间增量的位移 / 旋转
   */
  onUpdate(core) {

  }
}