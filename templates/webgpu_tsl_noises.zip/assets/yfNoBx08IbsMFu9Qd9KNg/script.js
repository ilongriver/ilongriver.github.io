class Script extends VD.Component {
  /**
   * 组件挂载时调用：初始化资源、订阅事件、设置初始状态（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例。常用字段：core.timer（计时器）、core.render.scene（三维场景）、core.render.camera（当前相机）、core.container（DOM 容器）
   */
  onMount(core) {
    const { Fn, vec2, float, floor, fract, length, min, sin, int, dot, Loop, uv, vec3, uniform } = TSL

    const uScale = uniform(5.0)

    const hash21 = Fn(([p]) => {
      const pp = vec2(
        dot(p, vec2(127.1, 311.7)),
        dot(p, vec2(269.5, 183.3)),
      );
      return fract(sin(pp).mul(43758.5453123));
    });


    const worleyNoise = Fn(([p]) => {
      const i = floor(p);
      const f = fract(p);
      const minDist = float(1.0).toVar();

      Loop({ start: int(-1), end: int(2), type: "int", name: "x" }, ({ x }) => {
        Loop({ start: int(-1), end: int(2), type: "int", name: "y" }, ({ y }) => {
          const neighbor = vec2(float(x), float(y));
          const point = hash21(i.add(neighbor));
          const diff = neighbor.add(point).sub(f);
          const dist = length(diff);
          minDist.assign(min(minDist, dist));
        });
      });

      return minDist.clamp(0.0, 1.0);
    });

    const material = new THREE.MeshBasicNodeMaterial()

    material.colorNode = Fn(() => {
      const p = uv().sub(0.5).mul(uScale);
      const result = worleyNoise(p);
      return vec3(result.clamp(0.0, 1.0));
    })();
    material.side = THREE.DoubleSide;

    this.object.material = material

    const gui = core.render.renderer.inspector.createParameters('Worley Noise');

    gui.add(uScale, 'value', 1, 50, 1).name('uScale')
  }

  /**
   * 组件卸载时调用：释放资源、取消订阅、清理监听器（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例，字段含义同 onMount
   */
  onUnmount(core) {

  }

  /**
   * 每帧更新回调：处理实时逻辑（运动、动画、碰撞检测、AI 等），会持续触发
   * @param {VD.Core} core 引擎核心实例。core.timer.getDelta() 可获取上一帧到当前的间隔秒数，常用于基于时间增量的位移 / 旋转
   */
  onUpdate(core) {

  }
}