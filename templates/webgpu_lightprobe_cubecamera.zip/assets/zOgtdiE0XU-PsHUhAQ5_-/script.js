class Script extends VD.Component {
  /**
   * @field
   * @type {THREE.Texture}
   */
  hdr
  /**
   * 组件挂载时调用：初始化资源、订阅事件、设置初始状态（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例。常用字段：core.timer（计时器）、core.render.scene（三维场景）、core.render.camera（当前相机）、core.container（DOM 容器）
   */
  async onMount(core) {
    const { scene, renderer } = core.render

    const cubeRenderTarget = new THREE.CubeRenderTarget(256, {
      type: THREE.HalfFloatType
    });

    this.cubeCamera = new THREE.CubeCamera(1, 1000, cubeRenderTarget);

    // probe
    this.lightProbe = new THREE.LightProbe();
    scene.add(this.lightProbe);

    this.cubeCamera.update(renderer, scene);

    const probe = await ADDONS.LightProbeGenerator.fromCubeRenderTarget(renderer, cubeRenderTarget);

    this.lightProbe.copy(probe);
    this.lightProbe.position.set(0, 1.1, 0)

    const helper = new ADDONS.LightProbeHelper(this.lightProbe, 0.5)

    scene.add(helper);
  }

  /**
   * 组件卸载时调用：释放资源、取消订阅、清理监听器（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例，字段含义同 onMount
   */
  onUnmount(core) {

  }

  /**
   * 每帧更新回调：处理实时逻辑（运动、动画、碰撞检测、AI 等），会持续触发
   * @param {VD.Core} core 引擎核心实例。core.timer.getDelta() 可获取上一帧到当前的间隔秒数，常用于基于时间增量的位移 / 旋转
   */
  onUpdate(core) {

  }
}