const { anaglyphPass, AnaglyphAlgorithm, AnaglyphColorMode, stereoPass, parallaxBarrierPass } = TSL

const position = new THREE.Vector3();

const params = {
  effect: 'stereo',
  eyeSep: 0.064,
  planeDistance: 3,
  anaglyphAlgorithm: 'dubois',
  anaglyphColorMode: 'redCyan'
};

const effects = { Stereo: 'stereo', Anaglyph: 'anaglyph', ParallaxBarrier: 'parallaxBarrier' };

const anaglyphAlgorithms = {
  'True': AnaglyphAlgorithm.TRUE,
  'Grey': AnaglyphAlgorithm.GREY,
  'Colour': AnaglyphAlgorithm.COLOUR,
  'Half-Colour': AnaglyphAlgorithm.HALF_COLOUR,
  'Dubois': AnaglyphAlgorithm.DUBOIS,
  'Optimised': AnaglyphAlgorithm.OPTIMISED,
  'Compromise': AnaglyphAlgorithm.COMPROMISE
};

const anaglyphColorModes = {
  'Red / Cyan': AnaglyphColorMode.RED_CYAN,
  'Magenta / Cyan': AnaglyphColorMode.MAGENTA_CYAN,
  'Magenta / Green': AnaglyphColorMode.MAGENTA_GREEN
};

class Script extends VD.Component {
  /**
   * @field
   * @type {THREE.Texture}
   */
  envMap
  /**
   * 组件挂载时调用：初始化资源、订阅事件、设置初始状态（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例。常用字段：core.timer（计时器）、core.render.scene（三维场景）、core.render.camera（当前相机）、core.container（DOM 容器）
   */
  onMount(core) {
    const geometry = new THREE.SphereGeometry(0.1, 32, 16);

    const material = new THREE.MeshBasicMaterial({ color: 0xffffff, envMap: this.envMap });

    this.mesh = new THREE.InstancedMesh(geometry, material, 500);
    this.mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);

    this.dummy = new THREE.Mesh();

    for (let i = 0; i < 500; i++) {

      this.dummy.position.x = Math.random() * 10 - 5;
      this.dummy.position.y = Math.random() * 10 - 5;
      this.dummy.position.z = Math.random() * 10 - 5;
      this.dummy.scale.x = this.dummy.scale.y = this.dummy.scale.z = Math.random() * 3 + 1;

      this.dummy.updateMatrix();

      this.mesh.setMatrixAt(i, this.dummy.matrix);

    }

    core.render.scene.add(this.mesh);

    this.stereo = stereoPass(core.render.scene, core.render.camera);
    this.anaglyph = anaglyphPass(core.render.scene, core.render.camera);
    this.parallaxBarrier = parallaxBarrierPass(core.render.scene, core.render.camera);

    // Configure anaglyph for physically-correct stereo with zero parallax at scene center
    this.anaglyph.eyeSep = params.eyeSep;
    this.anaglyph.planeDistance = params.planeDistance;

    core.render.pipeline.outputNode = this.stereo;

    const update = (value) => {

      if (value === 'stereo') {

        core.render.pipeline.outputNode = this.stereo;
        this.anaglyphFolder.paramList.domElement.style.display = 'none';

      } else if (value === 'anaglyph') {

        core.render.pipeline.outputNode = this.anaglyph;
        this.anaglyphFolder.paramList.domElement.style.display = '';

      } else if (value === 'parallaxBarrier') {

        core.render.pipeline.outputNode = this.parallaxBarrier;
        this.anaglyphFolder.paramList.domElement.style.display = 'none';

      }

      core.render.pipeline.needsUpdate = true;

    }

    const gui = core.render.renderer.inspector.createParameters('Stereo Settings');
    gui.add(params, 'effect', effects).onChange(update);
    gui.add(params, 'eyeSep', 0.001, 0.15, 0.001).onChange((value) => {

      this.stereo.stereo.eyeSep = value;
      this.anaglyph.eyeSep = value; // Anaglyph has direct eyeSep property
      this.parallaxBarrier.stereo.eyeSep = value;

    });

    // Anaglyph-specific settings folder
    this.anaglyphFolder = gui.addFolder('Anaglyph Options');
    this.anaglyphFolder.add(params, 'anaglyphAlgorithm', anaglyphAlgorithms).name('Algorithm').onChange((value) => {

      this.anaglyph.algorithm = value;

    });
    this.anaglyphFolder.add(params, 'anaglyphColorMode', anaglyphColorModes).name('Color Mode').onChange((value) => {

      this.anaglyph.colorMode = value;

    });
    this.anaglyphFolder.add(params, 'planeDistance', 0.5, 10, 0.1).name('Plane Distance').onChange((value) => {

      this.anaglyph.planeDistance = value;

    });
    this.anaglyphFolder.paramList.domElement.style.display = 'none';
  }

  /**
   * 组件卸载时调用：释放资源、取消订阅、清理监听器（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例，字段含义同 onMount
   */
  onUnmount(core) {

  }

  /**
   * 每帧更新回调：处理实时逻辑（运动、动画、碰撞检测、AI 等），会持续触发
   * @param {VD.Core} core 引擎核心实例。core.timer.getDelta() 可获取上一帧到当前的间隔秒数，常用于基于时间增量的位移 / 旋转
   */
  onUpdate(core) {
    const elapsedTime = core.timer.getElapsed() * 0.1;

    for (let i = 0; i < this.mesh.count; i++) {

      this.mesh.getMatrixAt(i, this.dummy.matrix);

      this.extractPosition(this.dummy.matrix, position);

      position.x = 5 * Math.cos(elapsedTime + i);
      position.y = 5 * Math.sin(elapsedTime + i * 1.1);

      this.dummy.matrix.setPosition(position);

      this.mesh.setMatrixAt(i, this.dummy.matrix);

      this.mesh.instanceMatrix.needsUpdate = true;

    }
  }

  extractPosition(matrix, position) {

    position.x = matrix.elements[12];
    position.y = matrix.elements[13];
    position.z = matrix.elements[14];

  }
}