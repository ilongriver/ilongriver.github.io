const pointLights = [];
let autoAddInterval = null;

class Script extends VD.Component {
  /**
   * 组件挂载时调用：初始化资源、订阅事件、设置初始状态（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例。常用字段：core.timer（计时器）、core.render.scene（三维场景）、core.render.camera（当前相机）、core.container（DOM 容器）
   */
  onMount(core) {
    const { scene, renderer } = core.render
    // Floor

    const floorGeometry = new THREE.PlaneGeometry(120, 120);
    const floorMaterial = new THREE.MeshStandardMaterial({ color: 0x444444, roughness: 0.8 });
    const floor = new THREE.Mesh(floorGeometry, floorMaterial);
    floor.rotation.x = - Math.PI / 2;
    scene.add(floor);

    // Shared geometries

    const sphereGeometry = new THREE.SphereGeometry(0.8, 128, 128);
    const boxGeometry = new THREE.BoxGeometry(1.2, 1.2, 1.2, 64, 64, 64);
    const torusGeometry = new THREE.TorusGeometry(0.6, 0.25, 128, 128);
    const cylinderGeometry = new THREE.CylinderGeometry(0.5, 0.5, 1.4, 128, 64);
    const coneGeometry = new THREE.ConeGeometry(0.6, 1.4, 128, 64);

    const geometries = [sphereGeometry, boxGeometry, torusGeometry, cylinderGeometry, coneGeometry];

    // 100 meshes — first 50 with unique PBR materials, remaining 50 reuse them

    const uniqueMaterials = [];

    for (let i = 0; i < 50; i++) {

      const material = new THREE.MeshStandardMaterial({
        color: new THREE.Color().setHSL(i / 50, 0.6 + Math.random() * 0.4, 0.35 + Math.random() * 0.3),
        roughness: Math.random(),
        metalness: Math.random(),
      });
      material.name = 'Standard_' + i;

      uniqueMaterials.push(material);

    }

    const meshesPerRing = 10;

    for (let i = 0; i < 100; i++) {

      const material = i < 50 ? uniqueMaterials[i] : uniqueMaterials[i - 50];
      const geometry = geometries[i % geometries.length];
      const mesh = new THREE.Mesh(geometry, material);

      const ring = Math.floor(i / meshesPerRing);
      const indexInRing = i % meshesPerRing;
      const angle = (indexInRing / meshesPerRing) * Math.PI * 2 + ring * 0.3;
      const radius = 6 + ring * 4;

      mesh.position.set(
        Math.cos(angle) * radius,
        0.7 + Math.random() * 2,
        Math.sin(angle) * radius
      );

      mesh.rotation.set(
        Math.random() * Math.PI,
        Math.random() * Math.PI,
        0
      );

      scene.add(mesh);

    }

    // Center sphere

    const centerMaterial = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.1, metalness: 0.9 });
    const centerSphere = new THREE.Mesh(new THREE.SphereGeometry(2, 128, 128), centerMaterial);
    centerSphere.position.y = 2;
    scene.add(centerSphere);


    this.params = {
      dynamic: true,
      autoAdd: false,
      lightCount: 2,
      addLight: () => {

        this.addLight();

      },
      removeLight: () => {

        this.removeLight();

      },
      removeAll: () => {

        this.removeAllLights();

      }
    };

    // Start with a couple point lights

    this.addLight();
    this.addLight();

    renderer.lighting = new ADDONS.DynamicLighting()

    const gui = renderer.inspector.createParameters('Dynamic Lights');
    gui.add(this.params, 'autoAdd').name('auto-add lights').onChange((value) => {

      if (value) {

        autoAddInterval = setInterval(() => {

          this.addLight();

        }, 500);

      } else {

        clearInterval(autoAddInterval);
        autoAddInterval = null;

      }

    });

    gui.add(this.params, 'addLight').name('add light');
    gui.add(this.params, 'removeLight').name('remove light');
    gui.add(this.params, 'removeAll').name('remove all lights');
    gui.add(this.params, 'lightCount').name('point lights').listen();
  }

  /**
   * 组件卸载时调用：释放资源、取消订阅、清理监听器（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例，字段含义同 onMount
   */
  onUnmount(core) {

  }

  /**
   * 每帧更新回调：处理实时逻辑（运动、动画、碰撞检测、AI 等），会持续触发
   * @param {VD.Core} core 引擎核心实例。core.timer.getDelta() 可获取上一帧到当前的间隔秒数，常用于基于时间增量的位移 / 旋转
   */
  onUpdate(core) {
    const time = core.timer.getElapsed();

    // Animate lights

    for (let i = 0; i < pointLights.length; i++) {

      const light = pointLights[i];
      const d = light.userData;
      const t = time * d.speed + d.angle;

      light.position.x = Math.cos(t) * d.radius;
      light.position.z = Math.sin(t) * d.radius;
      light.position.y = d.baseY + Math.sin(t * 2) * 0.5;

    }
  }

  addLight() {
    const { scene } = this.core.render

    const color = new THREE.Color().setHSL(Math.random(), 0.8, 0.5);
    const light = new THREE.PointLight(color, 1000);

    const angle = Math.random() * Math.PI * 2;
    const radius = 5 + Math.random() * 20;
    light.position.set(
      Math.cos(angle) * radius,
      1 + Math.random() * 6,
      Math.sin(angle) * radius
    );

    light.userData.angle = angle;
    light.userData.radius = radius;
    light.userData.speed = 0.2 + Math.random() * 0.8;
    light.userData.baseY = light.position.y;

    // Visual indicator
    const sphere = new THREE.Mesh(
      new THREE.SphereGeometry(0.15, 8, 8),
      new THREE.MeshBasicMaterial({ color: color })
    );
    light.add(sphere);

    scene.add(light);
    pointLights.push(light);

    this.params.lightCount = pointLights.length;

  }

  removeLight() {
    const { scene } = this.core.render

    if (pointLights.length === 0) return;

    const light = pointLights.pop();
    scene.remove(light);
    light.dispose();

    this.params.lightCount = pointLights.length;

  }

  removeAllLights() {
    const { scene } = this.core.render

    while (pointLights.length > 0) {

      const light = pointLights.pop();
      scene.remove(light);
      light.dispose();

    }

    this.params.lightCount = 0;

  }
}