class Script extends VD.Component {
  /**
   * 组件挂载时调用：初始化资源、订阅事件、设置初始状态（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例。常用字段：core.timer（计时器）、core.render.scene（三维场景）、core.render.camera（当前相机）、core.container（DOM 容器）
   */
  onMount(core) {
    const { color, storage, Fn, instancedBufferAttribute, instanceIndex, sin, time, float, uniform, shapeCircle, mix, vec3 } = TSL

    this.camera2 = new THREE.PerspectiveCamera(40, 1, 1, 1000);
    this.camera2.position.copy(core.render.camera.position);

    this.backgroundNode = color(0x222222);

    this.effectController = {

      pulseSpeed: uniform(6),
      minWidth: uniform(6),
      maxWidth: uniform(20)

    };

    // Position and THREE.Color Data

    const points = ADDONS.GeometryUtils.hilbert3D(new THREE.Vector3(0, 0, 0), 20.0, 1, 0, 1, 2, 3, 4, 5, 6, 7);

    const spline = new THREE.CatmullRomCurve3(points);
    const divisions = Math.round(4 * points.length);
    const point = new THREE.Vector3();
    const pointColor = new THREE.Color();

    const positions = [];
    const colors = [];
    const sizes = new Float32Array(divisions);

    for (let i = 0, l = divisions; i < l; i++) {

      const t = i / l;

      spline.getPoint(t, point);
      positions.push(point.x, point.y, point.z);

      pointColor.setHSL(t, 1.0, 0.5, THREE.SRGBColorSpace);
      colors.push(pointColor.r, pointColor.g, pointColor.b);

      sizes[i] = 10.0;

    }

    // Instanced Points

    const positionAttribute = new THREE.InstancedBufferAttribute(new Float32Array(positions), 3);
    const colorsAttribute = new THREE.InstancedBufferAttribute(new Float32Array(colors), 3);

    const instanceSizeBufferAttribute = new THREE.StorageInstancedBufferAttribute(sizes, 1);
    const instanceSizeStorage = storage(instanceSizeBufferAttribute, 'float', instanceSizeBufferAttribute.count);

    this.computeSize = Fn(() => {

      const { pulseSpeed, minWidth, maxWidth } = this.effectController;

      const relativeTime = time.add(float(instanceIndex));

      const sizeFactor = sin(relativeTime.mul(pulseSpeed)).add(1).div(2);

      instanceSizeStorage.element(instanceIndex).assign(sizeFactor.mul(maxWidth.sub(minWidth)).add(minWidth));

    })().compute(divisions);

    // Material / Sprites

    const attributeRange = instancedBufferAttribute(instanceSizeBufferAttribute);
    const pointColors = mix(vec3(0.0), instancedBufferAttribute(colorsAttribute), attributeRange.div(float(this.effectController.maxWidth)));

    this.material = new THREE.PointsNodeMaterial({

      colorNode: pointColors,
      opacityNode: shapeCircle(),
      positionNode: instancedBufferAttribute(positionAttribute),
      // rotationNode: time,
      sizeNode: instancedBufferAttribute(instanceSizeBufferAttribute),
      // size: 40, // in pixels units
      vertexColors: true,
      sizeAttenuation: false,
      alphaToCoverage: true

    });

    const instancedPoints = new THREE.Sprite(this.material);
    instancedPoints.count = divisions;
    core.render.scene.add(instancedPoints);

    // GUI

    const gui = core.render.renderer.inspector.createParameters('Settings');

    gui.add(this.material, 'alphaToCoverage');

    gui.add(this.effectController.minWidth, 'value', 1, 30, 1).name('minWidth');
    gui.add(this.effectController.maxWidth, 'value', 2, 30, 1).name('maxWidth');
    gui.add(this.effectController.pulseSpeed, 'value', 1, 20, 0.1).name('pulseSpeed');

    this.insetWidth = window.innerHeight / 4; // square
    this.insetHeight = window.innerHeight / 4;

    core.render.render = () => {
      core.render.renderer.render(core.render.scene, core.render.camera);
    }
  }

  onResize() {
    this.insetWidth = window.innerHeight / 4; // square
    this.insetHeight = window.innerHeight / 4;

    this.camera2.aspect = this.insetWidth / this.insetHeight;
    this.camera2.updateProjectionMatrix();
  }

  /**
   * 组件卸载时调用：释放资源、取消订阅、清理监听器（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例，字段含义同 onMount
   */
  onUnmount(core) {

  }

  /**
   * 每帧更新回调：处理实时逻辑（运动、动画、碰撞检测、AI 等），会持续触发
   * @param {VD.Core} core 引擎核心实例。core.timer.getDelta() 可获取上一帧到当前的间隔秒数，常用于基于时间增量的位移 / 旋转
   */
  onUpdate(core) {
    // compute

    core.render.renderer.compute(this.computeSize);
  }

  onRenderBefore(core) {
    const { renderer, scene } = core.render

    renderer.autoClear = true;

    scene.backgroundNode = null;

    renderer.setViewport(0, 0, window.innerWidth, window.innerHeight);
  }

  onRenderAfter(core) {
    const { renderer, camera, scene } = core.render
    // inset scene

    const posY = window.innerHeight - this.insetHeight - 20;

    renderer.clearDepth(); // important!

    renderer.setScissorTest(true);

    renderer.setScissor(20, posY, this.insetWidth, this.insetHeight);

    renderer.setViewport(20, posY, this.insetWidth, this.insetHeight);

    this.camera2.position.copy(camera.position);

    this.camera2.quaternion.copy(camera.quaternion);

    renderer.autoClear = false;

    scene.backgroundNode = this.backgroundNode;

    renderer.render(scene, this.camera2);

    renderer.setScissorTest(false);
  }
}