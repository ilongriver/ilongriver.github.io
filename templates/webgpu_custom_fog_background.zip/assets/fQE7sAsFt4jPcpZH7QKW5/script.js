const { pass, color, rangeFogFactor } = TSL

class Script extends VD.Component {
  /**
   * 组件挂载时调用：初始化资源、订阅事件、设置初始状态（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例。常用字段：core.timer（计时器）、core.render.scene（三维场景）、core.render.camera（当前相机）、core.container（DOM 容器）
   */
  onMount(core) {
    const { scene, camera } = core.render
    // post processing

    // render scene pass
    const scenePass = pass(scene, camera);
    const scenePassViewZ = scenePass.getViewZNode();

    // fog color
    const fogColor = color(0x4080cc); // in sRGB color space

    // get fog factor from the scene pass context
    // equivalent to: scene.fog = new THREE.Fog( 0x4080cc, 2.7, 4 );
    const fogFactor = rangeFogFactor(2.7, 4).context({ getViewZ: () => scenePassViewZ });

    // tone-mapped scene pass
    const scenePassTM = scenePass.toneMapping(THREE.ACESFilmicToneMapping, 1);

    // mix fog using fog factor and fog color
    const compose = fogFactor.mix(scenePassTM, fogColor);

    core.render.pipeline.outputColorTransform = true; // no tone mapping will be applied, only the default color space transform

    core.render.pipeline.outputNode = compose;
  }

  /**
   * 组件卸载时调用：释放资源、取消订阅、清理监听器（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例，字段含义同 onMount
   */
  onUnmount(core) {

  }

  /**
   * 每帧更新回调：处理实时逻辑（运动、动画、碰撞检测、AI 等），会持续触发
   * @param {VD.Core} core 引擎核心实例。core.timer.getDelta() 可获取上一帧到当前的间隔秒数，常用于基于时间增量的位移 / 旋转
   */
  onUpdate(core) {

  }
}