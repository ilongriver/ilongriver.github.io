const { gaussianBlur, Fn, texture, vec3, pass, color, uint, screenUV, instancedArray, positionWorld, positionLocal, time, vec2, hash, instanceIndex, If } = TSL

const maxParticleCount = 100000;

const Layer1 = 1 // 碰撞层

class Script extends VD.Component {
  /**
   * @field
   * @type {THREE.Object3D}
   */
  collisionCamera

  /**
   * 组件挂载时调用：初始化资源、订阅事件、设置初始状态（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例。常用字段：core.timer（计时器）、core.render.scene（三维场景）、core.render.camera（当前相机）、core.container（DOM 容器）
   */
  onMount(core) {
    core.render.camera.layers.enable(Layer1);
    core.render.camera.lookAt(0, 40, 0);

    this.collisionCamera.layers.set(Layer1);

    this.collisionPosRT = new THREE.RenderTarget(1024, 1024);
    this.collisionPosRT.texture.type = THREE.HalfFloatType;
    this.collisionPosRT.texture.magFilter = THREE.NearestFilter;
    this.collisionPosRT.texture.minFilter = THREE.NearestFilter;
    this.collisionPosRT.texture.generateMipmaps = false;

    this.collisionPosMaterial = new THREE.MeshBasicNodeMaterial();
    this.collisionPosMaterial.fog = false;
    this.collisionPosMaterial.toneMapped = false;
    this.collisionPosMaterial.colorNode = positionWorld;

    const positionBuffer = instancedArray(maxParticleCount, 'vec3');
    const scaleBuffer = instancedArray(maxParticleCount, 'vec3');
    const staticPositionBuffer = instancedArray(maxParticleCount, 'vec3');
    const dataBuffer = instancedArray(maxParticleCount, 'vec4');

    // compute

    const randUint = () => uint(Math.random() * 0xFFFFFF);

    const computeInit = Fn(() => {
      const position = positionBuffer.element(instanceIndex);
      const scale = scaleBuffer.element(instanceIndex);
      const particleData = dataBuffer.element(instanceIndex);

      const randX = hash(instanceIndex);
      const randY = hash(instanceIndex.add(randUint()));
      const randZ = hash(instanceIndex.add(randUint()));

      position.x = randX.mul(100).add(- 50);
      position.y = randY.mul(500).add(3);
      position.z = randZ.mul(100).add(- 50);

      scale.xyz = hash(instanceIndex.add(Math.random())).mul(.8).add(.2);

      staticPositionBuffer.element(instanceIndex).assign(vec3(1000, 10000, 1000));

      particleData.y = randY.mul(- .1).add(- .02);

      particleData.x = position.x;
      particleData.z = position.z;
      particleData.w = randX;

    })().compute(maxParticleCount).setName('Init Particles');

    //

    const surfaceOffset = .2;
    const speed = .4;

    const computeUpdate = Fn(() => {

      const getCoord = (pos) => pos.add(50).div(100);

      const position = positionBuffer.element(instanceIndex);
      const scale = scaleBuffer.element(instanceIndex);
      const particleData = dataBuffer.element(instanceIndex);

      const velocity = particleData.y;
      const random = particleData.w;

      const rippleOnSurface = texture(this.collisionPosRT.texture, getCoord(position.xz)).toInspector('Collision Test', () => {

        return texture(this.collisionPosRT.texture).y;

      });

      const rippleFloorArea = rippleOnSurface.y.add(scale.x.mul(surfaceOffset));

      If(position.y.greaterThan(rippleFloorArea), () => {

        position.x = particleData.x.add(time.mul(random.mul(random)).mul(speed).sin().mul(3));
        position.z = particleData.z.add(time.mul(random).mul(speed).cos().mul(random.mul(10)));

        position.y = position.y.add(velocity);

      }).Else(() => {
        staticPositionBuffer.element(instanceIndex).assign(position);

        const randX = hash(instanceIndex);
        const randY = hash(instanceIndex.add(randUint()));
        const randZ = hash(instanceIndex.add(randUint()));

        position.x = randX.mul(100).add(- 50);
        position.y = randY.mul(500).add(3);
        position.z = randZ.mul(100).add(- 50);
      });

    });

    this.computeParticles = computeUpdate().compute(maxParticleCount);
    this.computeParticles.name = 'Update Particles';

    // rain

    const geometry = new THREE.SphereGeometry(surfaceOffset, 5, 5);

    function particle(staticParticles) {

      const posBuffer = staticParticles ? staticPositionBuffer : positionBuffer;

      const staticMaterial = new THREE.MeshStandardNodeMaterial({
        color: 0xeeeeee,
        roughness: .9,
        metalness: 0
      });

      staticMaterial.positionNode = positionLocal.mul(scaleBuffer.toAttribute()).add(posBuffer.toAttribute());

      const rainParticles = new THREE.Mesh(geometry, staticMaterial);
      rainParticles.count = maxParticleCount;
      rainParticles.frustumCulled = false

      return rainParticles;

    }

    const dynamicParticles = particle();
    const staticParticles = particle(true);

    core.render.scene.add(dynamicParticles);
    core.render.scene.add(staticParticles);

    // floor geometry

    const floorGeometry = new THREE.PlaneGeometry(100, 100);
    floorGeometry.rotateX(- Math.PI / 2);

    const plane = new THREE.Mesh(floorGeometry, new THREE.MeshStandardMaterial({
      color: 0x0c1e1e,
      roughness: .5,
      metalness: 0,
      transparent: true
    }));

    plane.material.opacityNode = positionLocal.xz.mul(.05).distance(0).saturate().oneMinus();

    plane.layers.set(Layer1)

    core.render.scene.add(plane);

    // tree

    function tree(count = 8) {

      const coneMaterial = new THREE.MeshStandardNodeMaterial({
        color: 0x0d492c,
        roughness: .6,
        metalness: 0
      });

      const object = new THREE.Group();

      for (let i = 0; i < count; i++) {

        const radius = 1 + i;

        const coneGeometry = new THREE.ConeGeometry(radius * 0.95, radius * 1.25, 32);

        const cone = new THREE.Mesh(coneGeometry, coneMaterial);
        cone.position.y = ((count - i) * 1.5) + (count * .6);
        cone.layers.set(Layer1)
        object.add(cone);

      }

      const geometry = new THREE.CylinderGeometry(1, 1, count, 32);
      const cone = new THREE.Mesh(geometry, coneMaterial);
      cone.position.y = count / 2;
      cone.layers.set(Layer1)
      object.add(cone);

      return object;

    }

    const teapotTree = new THREE.Mesh(new THREE.OctahedronGeometry(), new THREE.MeshBasicNodeMaterial({
      color: 0xfcfb9e
    }));

    teapotTree.name = 'Teapot Pass';
    teapotTree.position.y = 18.5;

    core.render.scene.add(tree());
    core.render.scene.add(teapotTree);

    core.render.scene.backgroundNode = screenUV.distance(.5).mul(2).mix(color(0x0f4140), color(0x060a0d));

    // post processing

    const scenePass = pass(core.render.scene, core.render.camera);
    const scenePassColor = scenePass.getTextureNode();
    const vignette = screenUV.distance(.5).mul(1.35).clamp().oneMinus();

    const teapotTreePass = pass(teapotTree, core.render.camera).getTextureNode();
    const teapotTreePassBlurred = gaussianBlur(teapotTreePass, vec2(1), 6);
    teapotTreePassBlurred.resolutionScale = 0.2;

    const scenePassColorBlurred = gaussianBlur(scenePassColor);
    scenePassColorBlurred.resolutionScale = 0.5;
    scenePassColorBlurred.directionNode = vec2(1);

    // compose

    let totalPass = scenePass.toInspector('Scene');
    totalPass = totalPass.add(scenePassColorBlurred.mul(.1));
    totalPass = totalPass.mul(vignette);
    // totalPass = totalPass.add(teapotTreePass.mul(10).add(teapotTreePassBlurred).toInspector('Teapot Blur'));
    totalPass = totalPass.add(teapotTreePassBlurred.toInspector('Teapot Blur'));

    core.render.pipeline.outputNode = totalPass;

    core.render.renderer.compute(computeInit);
  }

  /**
   * 组件卸载时调用：释放资源、取消订阅、清理监听器（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例，字段含义同 onMount
   */
  onUnmount(core) {

  }

  /**
   * 每帧更新回调：处理实时逻辑（运动、动画、碰撞检测、AI 等），会持续触发
   * @param {VD.Core} core 引擎核心实例。core.timer.getDelta() 可获取上一帧到当前的间隔秒数，常用于基于时间增量的位移 / 旋转
   */
  onUpdate(core) {
    core.render.scene.overrideMaterial = this.collisionPosMaterial;
    core.render.renderer.setRenderTarget(this.collisionPosRT);
    core.render.renderer.render(core.render.scene, this.collisionCamera);

    // compute

    core.render.renderer.compute(this.computeParticles);

    // result

    core.render.scene.overrideMaterial = null;
    core.render.renderer.setRenderTarget(null);
  }
}