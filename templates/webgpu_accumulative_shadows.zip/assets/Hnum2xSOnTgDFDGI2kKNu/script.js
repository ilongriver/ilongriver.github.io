const { abs, cameraPosition, float, fract, fwidth, max, min, mix, positionLocal, positionWorld, pow, smoothstep, uniform, vec3, vec4 } = TSL;

/**
 * 无限网格：平面跟随相机在 XZ 平面移动，网格线按世界坐标计算，
 * 远处按距离淡出，线条密度接近像素时额外淡出以避免摩尔纹。
 * 挂到任意空物体上，网格的高度 / 旋转跟随该物体。
 */
class InfiniteGrid extends VD.Component {
  /**
   * @field
   * @type {number}
   * @label 细格大小
   * @min 0.01
   * @step 0.1
   * @precision 2
   */
  cellSize = 1;

  /**
   * @field
   * @type {number}
   * @label 细格线宽
   * @min 0
   * @max 5
   * @step 0.1
   * @precision 1
   */
  cellThickness = 1;

  /**
   * @field
   * @type {THREE.Color}
   * @label 细格颜色
   */
  cellColor = new THREE.Color('#6f6f6f');

  /**
   * @field
   * @type {number}
   * @label 粗格大小
   * @min 0.01
   * @step 0.5
   * @precision 2
   */
  sectionSize = 5;

  /**
   * @field
   * @type {number}
   * @label 粗格线宽
   * @min 0
   * @max 5
   * @step 0.1
   * @precision 1
   */
  sectionThickness = 1.5;

  /**
   * @field
   * @type {THREE.Color}
   * @label 粗格颜色
   */
  sectionColor = new THREE.Color('#9d4b4b');

  /**
   * @field
   * @type {number}
   * @label 淡出距离
   * @min 1
   * @step 1
   * @precision 0
   */
  fadeDistance = 60;

  /**
   * @field
   * @type {number}
   * @label 淡出强度
   * @min 0
   * @max 10
   * @step 0.1
   * @precision 1
   */
  fadeStrength = 1;

  /**
   * @field
   * @type {boolean}
   * @label 跟随相机
   * @tip 关闭后网格固定在物体位置，不再无限延伸
   */
  followCamera = true;

  onMount(core) {
    this.uCellSize = uniform(this.cellSize);
    this.uCellThickness = uniform(this.cellThickness);
    this.uCellColor = uniform(this.cellColor);
    this.uSectionSize = uniform(this.sectionSize);
    this.uSectionThickness = uniform(this.sectionThickness);
    this.uSectionColor = uniform(this.sectionColor);
    this.uFadeDistance = uniform(this.fadeDistance);
    this.uFadeStrength = uniform(this.fadeStrength);
    this.uFollow = uniform(this.followCamera ? 1 : 0);

    const getGrid = (size, thickness) => {
      const r = positionWorld.xz.div(size);
      const width = fwidth(r);
      const grid = abs(fract(r.sub(0.5)).sub(0.5)).div(width);
      const line = min(grid.x, grid.y).add(1).sub(thickness);
      const density = smoothstep(0.2, 0.5, max(width.x, width.y));

      return float(1).sub(min(line, 1)).mul(float(1).sub(density));
    };

    const g1 = getGrid(this.uCellSize, this.uCellThickness);
    const g2 = getGrid(this.uSectionSize, this.uSectionThickness);

    const dist = positionWorld.sub(cameraPosition).length();
    const fade = pow(float(1).sub(min(dist.div(this.uFadeDistance), 1)), this.uFadeStrength);

    const color = mix(this.uCellColor, this.uSectionColor, min(g2.mul(this.uSectionThickness), 1));
    const alpha = g1.add(g2).mul(fade);

    const material = new THREE.MeshBasicNodeMaterial({
      transparent: true,
      depthWrite: false,
      side: THREE.DoubleSide,
      fog: false,
    });

    // 跟随相机时平面中心始终位于相机正下方，网格线用世界坐标计算所以不会跟着滑动
    const offset = vec3(cameraPosition.x, 0, cameraPosition.z).mul(this.uFollow);

    material.positionNode = positionLocal.add(offset);
    material.fragmentNode = vec4(color, mix(alpha.mul(0.75), alpha, g2));

    const size = this.fadeDistance * 2.2;
    const geometry = new THREE.PlaneGeometry(size, size);

    geometry.rotateX(-Math.PI / 2);

    this.mesh = new THREE.Mesh(geometry, material);
    this.mesh.frustumCulled = false;
    this.mesh.raycast = () => {};

    this.object.add(this.mesh);
  }

  onRenderBefore() {
    this.uCellSize.value = this.cellSize;
    this.uCellThickness.value = this.cellThickness;
    this.uCellColor.value.copy(this.cellColor);
    this.uSectionSize.value = this.sectionSize;
    this.uSectionThickness.value = this.sectionThickness;
    this.uSectionColor.value.copy(this.sectionColor);
    this.uFadeDistance.value = this.fadeDistance;
    this.uFadeStrength.value = this.fadeStrength;
    this.uFollow.value = this.followCamera ? 1 : 0;
  }

  onUnmount() {
    this.mesh?.removeFromParent();
  }

  onDestroy() {
    this.mesh?.geometry.dispose();
    this.mesh?.material.dispose();
  }
}