const { exponentialHeightFogFactor, uniform, fog, color } = TSL

class Script extends VD.Component {
  /**
   * 组件挂载时调用：初始化资源、订阅事件、设置初始状态（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例。常用字段：core.timer（计时器）、core.render.scene（三维场景）、core.render.camera（当前相机）、core.container（DOM 容器）
   */
  onMount(core) {
    // height fog

    const density = uniform(0.04);
    const height = uniform(2);

    const fogFactor = exponentialHeightFogFactor(density, height);

    core.render.scene.fogNode = fog(color(0xffdfc1), fogFactor);
    core.render.scene.backgroundNode = color(0xffdfc1);

    // meshes

    const geometry = new THREE.BoxGeometry(1, 25, 1);
    const material = new THREE.MeshPhongNodeMaterial({ color: 0xcd959a });

    const mesh = new THREE.InstancedMesh(geometry, material, 100);
    mesh.position.y = - 10;
    core.render.scene.add(mesh);

    const dummy = new THREE.Object3D();

    let index = 0;

    for (let i = 0; i < 10; i++) {

      for (let j = 0; j < 10; j++) {

        dummy.position.x = - 18 + (i * 4);
        dummy.position.z = - 18 + (j * 4);

        dummy.updateMatrix();

        mesh.setMatrixAt(index++, dummy.matrix);

      }

    }

    // gui

    const gui = core.render.renderer.inspector.createParameters('Fog Settings');

    gui.add(density, 'value', 0.001, 0.1).step(0.0001).name('Density');
    gui.add(height, 'value', - 5, 5).name('Height');
  }

  /**
   * 组件卸载时调用：释放资源、取消订阅、清理监听器（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例，字段含义同 onMount
   */
  onUnmount(core) {

  }

  /**
   * 每帧更新回调：处理实时逻辑（运动、动画、碰撞检测、AI 等），会持续触发
   * @param {VD.Core} core 引擎核心实例。core.timer.getDelta() 可获取上一帧到当前的间隔秒数，常用于基于时间增量的位移 / 旋转
   */
  onUpdate(core) {

  }
}