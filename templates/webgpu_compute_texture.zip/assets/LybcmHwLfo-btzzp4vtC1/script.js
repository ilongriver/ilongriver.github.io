const { texture, textureStore, Fn, instanceIndex, float, uvec2, vec4, time } = TSL

class Script extends VD.Component {
  /**
   * 组件挂载时调用：初始化资源、订阅事件、设置初始状态（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例。常用字段：core.timer（计时器）、core.render.scene（三维场景）、core.render.camera（当前相机）、core.container（DOM 容器）
   */
  onMount(core) {
    // texture

    const width = 512, height = 512;

    const storageTexture = new THREE.StorageTexture(width, height);
    //storageTexture.minFilter = THREE.LinearMipMapLinearFilter;

    // create function

    const computeTexture = Fn(({ storageTexture }) => {

      const posX = instanceIndex.mod(width);
      const posY = instanceIndex.div(width);
      const indexUV = uvec2(posX, posY);

      // https://www.shadertoy.com/view/Xst3zN

      const x = float(posX).div(50.0);
      const y = float(posY).div(50.0);

      const t = time.mul(0.5);

      const v1 = x.add(t).sin();
      const v2 = y.sub(t).sin();
      const v3 = x.add(y).add(t.mul(0.7)).sin();
      const v4 = x.mul(x).add(y.mul(y)).sqrt().sub(t).add(5).sin();

      const v = v1.add(v2, v3, v4);

      const r = v.sin();
      const g = v.add(Math.PI).sin();
      const b = v.add(Math.PI).sub(0.5).sin();

      textureStore(storageTexture, indexUV, vec4(r, g, b, 1)).toWriteOnly();

    });

    // compute

    this.computeNode = computeTexture({ storageTexture }).compute(width * height);

    const material = new THREE.MeshBasicNodeMaterial({ color: 0x00ff00 });
    material.colorNode = texture(storageTexture);

    const plane = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), material);
    core.render.scene.add(plane);

    this.onResize()
  }

  /**
   * 组件卸载时调用：释放资源、取消订阅、清理监听器（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例，字段含义同 onMount
   */
  onUnmount(core) {

  }

  /**
   * 每帧更新回调：处理实时逻辑（运动、动画、碰撞检测、AI 等），会持续触发
   * @param {VD.Core} core 引擎核心实例。core.timer.getDelta() 可获取上一帧到当前的间隔秒数，常用于基于时间增量的位移 / 旋转
   */
  onUpdate(core) {
    core.render.renderer.compute(this.computeNode);
  }

  onResize() {
    const aspect = window.innerWidth / window.innerHeight;

    const frustumHeight = this.object.top - this.object.bottom;

    this.object.left = - frustumHeight * aspect / 2;
    this.object.right = frustumHeight * aspect / 2;

    this.object.updateProjectionMatrix();
  }
}