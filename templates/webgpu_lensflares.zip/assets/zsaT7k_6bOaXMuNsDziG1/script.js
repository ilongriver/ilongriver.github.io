class Script extends VD.Component {
  /**
   * @field 
   * @type {THREE.Texture}
   */
  textureFlare0
  /**
   * @field 
   * @type {THREE.Texture}
   */
  textureFlare3
  /**
   * 组件挂载时调用：初始化资源、订阅事件、设置初始状态（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例。常用字段：core.timer（计时器）、core.render.scene（三维场景）、core.render.camera（当前相机）、core.container（DOM 容器）
   */
  onMount(core) {
    const { scene } = core.render

    scene.background = new THREE.Color().setHSL(0.51, 0.4, 0.01, THREE.SRGBColorSpace);
    scene.fog = new THREE.Fog(scene.background, 3500, 15000);

    // world

    const s = 250;

    const geometry = new THREE.BoxGeometry(s, s, s);
    const material = new THREE.MeshPhongNodeMaterial({ color: 0xffffff, specular: 0xffffff, shininess: 50 });

    for (let i = 0; i < 3000; i++) {

      const mesh = new THREE.Mesh(geometry, material);

      mesh.position.x = 8000 * (2.0 * Math.random() - 1.0);
      mesh.position.y = 8000 * (2.0 * Math.random() - 1.0);
      mesh.position.z = 8000 * (2.0 * Math.random() - 1.0);

      mesh.rotation.x = Math.random() * Math.PI;
      mesh.rotation.y = Math.random() * Math.PI;
      mesh.rotation.z = Math.random() * Math.PI;

      mesh.matrixAutoUpdate = false;
      mesh.updateMatrix();

      scene.add(mesh);

    }

    // lights

    const dirLight = new THREE.DirectionalLight(0xffffff, 0.15);
    dirLight.position.set(0, - 1, 0).normalize();
    dirLight.color.setHSL(0.1, 0.7, 0.5);
    scene.add(dirLight);

    // lensflares
    this.addLight(0.55, 0.95, 0.6, 5000, 0, - 1000);
    this.addLight(0.1, 0.85, 0.65, 0, 0, - 1000);
    this.addLight(0.995, 0.5, 0.95, 5000, 5000, - 1000);
  }

  /**
   * 组件卸载时调用：释放资源、取消订阅、清理监听器（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例，字段含义同 onMount
   */
  onUnmount(core) {

  }

  /**
   * 每帧更新回调：处理实时逻辑（运动、动画、碰撞检测、AI 等），会持续触发
   * @param {VD.Core} core 引擎核心实例。core.timer.getDelta() 可获取上一帧到当前的间隔秒数，常用于基于时间增量的位移 / 旋转
   */
  onUpdate(core) {

  }

  addLight(h, s, l, x, y, z) {
    const { scene } = this.core.render

    const light = new THREE.PointLight(0xffffff, 1.5, 2000, 0);
    light.color.setHSL(h, s, l);
    light.position.set(x, y, z);
    scene.add(light);

    const lensflare = new ADDONS.LensflareMesh();
    lensflare.addElement(new ADDONS.LensflareElement(this.textureFlare0, 700, 0, light.color));
    lensflare.addElement(new ADDONS.LensflareElement(this.textureFlare3, 60, 0.6));
    lensflare.addElement(new ADDONS.LensflareElement(this.textureFlare3, 70, 0.7));
    lensflare.addElement(new ADDONS.LensflareElement(this.textureFlare3, 120, 0.9));
    lensflare.addElement(new ADDONS.LensflareElement(this.textureFlare3, 70, 1));
    light.add(lensflare);

  }
}