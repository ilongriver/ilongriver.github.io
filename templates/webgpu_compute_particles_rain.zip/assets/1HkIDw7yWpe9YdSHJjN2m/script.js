class Script extends VD.Component {
  /**
   * @field
   * @type {number}
   * @label Volume
   * @min 0
   * @max 1
   * @step 0.01
   */
  volume = 0.5;

  /**
   * @field
   * @type {boolean}
   * @label Loop
   */
  loop = true;

  /**
   * @field
   * @type {AudioClip}
   */
  music

  /**
   * 组件挂载时：创建 AudioListener 并加载背景音乐
   */
  async onMount() {
    this.listener = new THREE.AudioListener();

    this.object.add(this.listener);

    // 创建全局 Audio 对象
    this.sound = new THREE.Audio(this.listener);

    const audioBuffer = await this.music.getBuffer();

    this.sound.setBuffer(audioBuffer);
    this.sound.setLoop(this.loop);
    this.sound.setVolume(this.volume);
  }

  /**
   * 组件卸载时：停止播放并释放资源
   */
  onUnmount() {
    this.sound.stop();
    this.sound.disconnect();
    this.sound = null;

    this.listener.removeFromParent();
    this.listener = null;
  }

  onClick() {
    this.sound.play()
    console.log('🎵 背景音乐开始播放');
  }
}