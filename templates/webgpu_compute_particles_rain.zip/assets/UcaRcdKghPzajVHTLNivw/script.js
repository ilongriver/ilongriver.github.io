const { Fn, texture, uv, uint, instancedArray, positionWorld, billboarding, time, hash, deltaTime, vec2, instanceIndex, positionGeometry, If } = TSL

const maxParticleCount = 50000;
const instanceCount = maxParticleCount / 2;

class Script extends VD.Component {
  /**
   * @field
   * @type {THREE.Object3D}
   */
  collisionCamera

  /**
   * 组件挂载时调用：初始化资源、订阅事件、设置初始状态（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例。常用字段：core.timer（计时器）、core.render.scene（三维场景）、core.render.camera（当前相机）、core.container（DOM 容器）
   */
  onMount(core) {
    this.collisionCamera.layers.disableAll();
    this.collisionCamera.layers.enable(1);

    this.collisionPosRT = new THREE.RenderTarget(1024, 1024);
    this.collisionPosRT.texture.type = THREE.HalfFloatType; // 使用HalfFloatType后，纹理范围[-65504, 65504],为浮点数，能够表示位置
    this.collisionPosRT.texture.magFilter = THREE.NearestFilter;
    this.collisionPosRT.texture.minFilter = THREE.NearestFilter;
    this.collisionPosRT.texture.generateMipmaps = false;

    this.collisionPosMaterial = new THREE.MeshBasicNodeMaterial();
    this.collisionPosMaterial.colorNode = positionWorld; // 只会采样位于正交相机内的物体，颜色由世界位置决定

    const positionBuffer = instancedArray(maxParticleCount, 'vec3');
    const velocityBuffer = instancedArray(maxParticleCount, 'vec3');
    const ripplePositionBuffer = instancedArray(maxParticleCount, 'vec3');
    const rippleTimeBuffer = instancedArray(maxParticleCount, 'vec3');

    // compute

    const randUint = () => uint(Math.random() * 0xFFFFFF);

    const computeInit = Fn(() => {
      const position = positionBuffer.element(instanceIndex);
      const velocity = velocityBuffer.element(instanceIndex);
      const rippleTime = rippleTimeBuffer.element(instanceIndex);

      const randX = hash(instanceIndex);
      const randY = hash(instanceIndex.add(randUint()));
      const randZ = hash(instanceIndex.add(randUint()));

      position.x = randX.mul(100).add(- 50);
      position.y = randY.mul(25);
      position.z = randZ.mul(100).add(- 50);

      velocity.y = randX.mul(- .04).add(- .2);

      rippleTime.x = 1000;

    })().compute(maxParticleCount);

    const computeUpdate = Fn(() => {

      const getCoord = (pos) => pos.add(50).div(100);

      const position = positionBuffer.element(instanceIndex);
      const velocity = velocityBuffer.element(instanceIndex);
      const ripplePosition = ripplePositionBuffer.element(instanceIndex);
      const rippleTime = rippleTimeBuffer.element(instanceIndex);

      position.addAssign(velocity);

      rippleTime.x = rippleTime.x.add(deltaTime.mul(4));

      //

      const collisionArea = texture(this.collisionPosRT.texture, getCoord(position.xz));

      const surfaceOffset = .05;

      const floorPosition = collisionArea.y.add(surfaceOffset);

      // floor

      const ripplePivotOffsetY = - .9;

      If(position.y.add(ripplePivotOffsetY).lessThan(floorPosition), () => {

        position.y = 25;

        ripplePosition.xz = position.xz;
        ripplePosition.y = floorPosition;

        // reset hit time: x = time

        rippleTime.x = 1;

        // next drops will not fall in the same place

        position.x = hash(instanceIndex.add(time)).mul(100).add(- 50);
        position.z = hash(instanceIndex.add(time.add(randUint()))).mul(100).add(- 50);

      });

      const rippleOnSurface = texture(this.collisionPosRT.texture, getCoord(ripplePosition.xz));

      const rippleFloorArea = rippleOnSurface.y.add(surfaceOffset);

      If(ripplePosition.y.greaterThan(rippleFloorArea), () => {

        rippleTime.x = 1000;

      });

    });

    this.computeParticles = computeUpdate().compute(maxParticleCount).setName('Particles');

    // rain

    const rainMaterial = new THREE.MeshBasicNodeMaterial();
    rainMaterial.colorNode = uv().distance(vec2(.5, 0)).oneMinus().mul(3).exp().mul(.1);
    rainMaterial.vertexNode = billboarding({ position: positionBuffer.toAttribute() });
    rainMaterial.opacity = .2;
    rainMaterial.side = THREE.DoubleSide;
    rainMaterial.forceSinglePass = true;
    rainMaterial.depthWrite = false;
    rainMaterial.depthTest = true;
    rainMaterial.transparent = true;

    const rainParticles = new THREE.Mesh(new THREE.PlaneGeometry(.1, 2), rainMaterial);
    rainParticles.count = instanceCount;
    core.render.scene.add(rainParticles);

    // ripple

    const rippleTime = rippleTimeBuffer.element(instanceIndex).x;

    const rippleEffect = Fn(() => {

      const center = uv().add(vec2(- .5)).length().mul(7);
      const distance = rippleTime.sub(center);

      return distance.min(1).sub(distance.max(1).sub(1));

    });

    const rippleMaterial = new THREE.MeshBasicNodeMaterial();
    rippleMaterial.colorNode = rippleEffect();
    rippleMaterial.positionNode = positionGeometry.add(ripplePositionBuffer.toAttribute());
    rippleMaterial.opacityNode = rippleTime.mul(.3).oneMinus().max(0).mul(.5);
    rippleMaterial.side = THREE.DoubleSide;
    rippleMaterial.forceSinglePass = true;
    rippleMaterial.depthWrite = false;
    rippleMaterial.depthTest = true;
    rippleMaterial.transparent = true;

    // ripple geometry

    const surfaceRippleGeometry = new THREE.PlaneGeometry(2.5, 2.5);
    surfaceRippleGeometry.rotateX(- Math.PI / 2);

    const xRippleGeometry = new THREE.PlaneGeometry(1, 2);
    xRippleGeometry.rotateY(- Math.PI / 2);

    const zRippleGeometry = new THREE.PlaneGeometry(1, 2);

    const rippleGeometry = ADDONS.BufferGeometryUtils.mergeGeometries([surfaceRippleGeometry, xRippleGeometry, zRippleGeometry]);

    const rippleParticles = new THREE.Mesh(rippleGeometry, rippleMaterial);
    rippleParticles.count = instanceCount;
    core.render.scene.add(rippleParticles);

    // floor geometry

    const floorGeometry = new THREE.PlaneGeometry(1000, 1000);
    floorGeometry.rotateX(- Math.PI / 2);

    const plane = new THREE.Mesh(floorGeometry, new THREE.MeshBasicMaterial({ color: 0x050505 }));
    core.render.scene.add(plane);

    this.collisionBox = new THREE.Mesh(new THREE.BoxGeometry(30, 1, 15), new THREE.MeshStandardMaterial());
    this.collisionBox.material.color.set(0x333333);
    this.collisionBox.position.y = 12;
    this.collisionBox.scale.x = 3.5;
    this.collisionBox.layers.enable(1);
    core.render.scene.add(this.collisionBox);

    core.render.renderer.compute(computeInit);

    // gui

    const gui = core.render.renderer.inspector.createParameters('Settings');

    // use lerp to smooth the movement
    this.collisionBoxPosUI = new THREE.Vector3().copy(this.collisionBox.position);
    this.collisionBoxPos = new THREE.Vector3();

    gui.add(this.collisionBoxPosUI, 'z', - 50, 50, .001).name('position');
    gui.add(this.collisionBox.scale, 'x', .1, 3.5, 0.01).name('scale');
    gui.add(rainParticles, 'count', 200, maxParticleCount, 1).name('drop count').onChange((v) => rippleParticles.count = v);
  }

  /**
   * 组件卸载时调用：释放资源、取消订阅、清理监听器（整个生命周期只执行一次）
   * @param {VD.Core} core 引擎核心实例，字段含义同 onMount
   */
  onUnmount(core) {

  }

  /**
   * 每帧更新回调：处理实时逻辑（运动、动画、碰撞检测、AI 等），会持续触发
   * @param {VD.Core} core 引擎核心实例。core.timer.getDelta() 可获取上一帧到当前的间隔秒数，常用于基于时间增量的位移 / 旋转
   */
  onUpdate(core) {
    const delta = core.timer.getDelta();

    if (this.monkey) {

      this.monkey.rotation.y += delta;

    }

    this.collisionBoxPos.set(this.collisionBoxPosUI.x, this.collisionBoxPosUI.y, - this.collisionBoxPosUI.z);

    this.collisionBox.position.lerp(this.collisionBoxPos, 10 * delta);

    // position

    core.render.scene.overrideMaterial = this.collisionPosMaterial;
    core.render.renderer.setRenderTarget(this.collisionPosRT);
    core.render.renderer.render(core.render.scene, this.collisionCamera);

    // compute

    core.render.renderer.compute(this.computeParticles);

    // result

    core.render.scene.overrideMaterial = null;
    core.render.renderer.setRenderTarget(null);
  }
}